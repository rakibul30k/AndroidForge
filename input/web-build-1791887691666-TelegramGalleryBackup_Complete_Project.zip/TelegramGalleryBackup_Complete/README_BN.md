# Telegram Gallery Backup — Android Studio project

## MT Manager দিয়ে Token/URL পরে সেট করার উপায়
এই প্রজেক্টে `app/src/main/assets/XX.json` নমুনা কনফিগারেশন আছে। APK-এর assets সরাসরি বদলালে APK আবার sign/reinstall করতে হতে পারে; ইনস্টল করা অ্যাপের ভেতরের asset edit করলেই বদলায় না।

সহজ পদ্ধতি:
1. ফোনে `XX.json` নামে একটি JSON ফাইল রাখুন, যেমন Downloads ফোল্ডারে।
2. MT Manager দিয়ে ফাইলটি সম্পাদনা করুন:
   {
     "bot_token": "YOUR_BOT_TOKEN",
     "channel_id": "-1001234567890",
     "premium_video_url": "https://example.com/video",
     "api_url": ""
   }
3. অ্যাপ খুলে “MT Manager দিয়ে সম্পাদিত XX.json লোড করো” চাপুন এবং ফাইলটি বেছে নিন।
4. সেটিংস লোড হলে “গ্যালারি ব্যাকআপ শুরু” চাপুন।

## Build
1. ZIP extract করুন।
2. Android Studio-তে `TelegramGalleryBackup_Complete` ফোল্ডার খুলুন।
3. Gradle sync করুন।
4. Run অথবা Build > Build APK(s) নির্বাচন করুন।
5. Telegram bot তৈরি করুন, bot-কে ব্যক্তিগত channel-এ admin করুন, posting permission দিন।
6. `channel_id` সঠিক দিন। সাধারণত private channel ID `-100...` দিয়ে শুরু হয়।

## কী করে
- MediaStore থেকে accessible gallery images পড়ে।
- WorkManager-এ internet constraint দিয়ে ছবিগুলো Telegram `sendDocument` endpoint-এ পাঠায়।
- পাঠানো MediaStore IDs সংরক্ষণ করে, যাতে একই বর্তমান media ID পুনরায় পাঠানোর সম্ভাবনা কমে।
- `XX.json` ফাইল অ্যাপ থেকে import করা যায়; পরে MT Manager দিয়ে সম্পাদনা করে পুনরায় import করা যায়।

## সীমাবদ্ধতা
- এটি একটি starter project; এখানে কম্পাইল/বাস্তব ডিভাইসে পরীক্ষা চালানো হয়নি। Android Studio build error হলে error text দেখে ঠিক করতে হবে।
- সব ছবি একবারে ব্যাকআপ করার জন্য দীর্ঘ-running foreground worker, content hash, robust retry/backoff ও database history production সংস্করণে যোগ করা উচিত।
- নতুন ছবি স্বয়ংক্রিয়ভাবে detect করার periodic scanner এখনও নেই; নতুন ছবি ব্যাকআপ করতে আবার Start Backup চাপতে হতে পারে।
- Premium Video URL শুধু কনফিগারেশন হিসেবে রাখা হয়; ভিডিও প্লেয়ার/ডাউনলোডার নেই।
- Bot Token অ্যাপে দিলে APK বিশ্লেষণ করে তা বের করা সম্ভব; নিজের ব্যক্তিগত বট ছাড়া ব্যবহার করবেন না।
- Telegram API limits ও network failures-এর কারণে সব upload নিশ্চিত নয়। ব্যাকআপ যাচাই না করে গ্যালারি থেকে ছবি মুছবেন না।
