package com.riyan.gallerybackup

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.graphics.Color
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager

class MainActivity : AppCompatActivity() {
    private lateinit var tokenInput: EditText
    private lateinit var chatInput: EditText
    private lateinit var videoInput: EditText
    private lateinit var apiInput: EditText
    private lateinit var statusText: TextView

    private val configPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {}
            try {
                statusText.text = ConfigStore.importJson(this, uri)
                loadFields()
            } catch (e: Exception) {
                statusText.text = "XX.json লোড হয়নি: ${e.message}"
            }
        }
    }

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startBackup() else statusText.text = "অনুমতি দেওয়া হয়নি। Settings থেকে Photos permission দিন।"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        loadFields()
        refreshStatus()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
            setBackgroundColor(Color.rgb(8, 19, 33))
        }
        fun label(text: String) = TextView(this).apply {
            this.text = text; textSize = 15f; setTextColor(Color.WHITE)
            setPadding(0, 16, 0, 7)
        }
        fun field(hint: String, secret: Boolean = false) = EditText(this).apply {
            this.hint = hint; setHintTextColor(Color.LTGRAY); setTextColor(Color.WHITE)
            setSingleLine(true); setPadding(20, 14, 20, 14)
            setBackgroundColor(Color.rgb(19, 37, 59))
            if (secret) inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }

        root.addView(TextView(this).apply {
            text = "☁️ Gallery Backup"; textSize = 25f; gravity = Gravity.CENTER
            setTextColor(Color.rgb(67, 200, 255)); setPadding(0, 0, 0, 10)
        })
        root.addView(label("Telegram Bot Token"))
        tokenInput = field("BotFather Token", true); root.addView(tokenInput, matchWidth())
        root.addView(label("Telegram Channel ID / Chat ID"))
        chatInput = field("উদাহরণ: -1001234567890"); root.addView(chatInput, matchWidth())
        root.addView(label("Premium Video URL (ঐচ্ছিক)"))
        videoInput = field("https://example.com/video"); root.addView(videoInput, matchWidth())
        root.addView(label("API URL (ঐচ্ছিক)"))
        apiInput = field("https://example.com/api"); root.addView(apiInput, matchWidth())

        addButton(root, "সেটিংস সংরক্ষণ") {
            saveFields()
            statusText.text = "সেটিংস সংরক্ষিত।"
        }
        addButton(root, "MT Manager দিয়ে সম্পাদিত XX.json লোড করো") {
            configPicker.launch(arrayOf("application/json", "text/*", "application/octet-stream"))
        }
        addButton(root, "Test Connection") {
            saveFields()
            val c = ConfigStore.load(this)
            statusText.text = if (c.botToken.isNotBlank() && c.chatId.isNotBlank() &&
                c.botToken != "ADD_BOT_TOKEN_HERE" && c.chatId != "ADD_CHANNEL_ID_HERE")
                "Token ও Chat ID দেওয়া আছে। আসল সংযোগ যাচাই করতে ব্যাকআপ চালাও।"
            else "আগে Bot Token ও Channel ID পূরণ করো।"
        }
        addButton(root, "গ্যালারি ব্যাকআপ শুরু") {
            saveFields()
            requestPermissionAndStart()
        }
        addButton(root, "স্ট্যাটাস রিফ্রেশ") { refreshStatus() }

        statusText = TextView(this).apply {
            textSize = 14f; setTextColor(Color.rgb(165, 233, 255))
            setPadding(0, 20, 0, 12); text = "ব্যাকআপের অবস্থা এখানে দেখা যাবে।"
        }
        root.addView(statusText)
        root.addView(TextView(this).apply {
            text = "XX.json ফাইলটি MT Manager দিয়ে সম্পাদনা করে, এখানে 'XX.json লোড করো' চাপুন. Token গোপন রাখুন."
            textSize = 12f; setTextColor(Color.LTGRAY); setPadding(0, 10, 0, 0)
        })
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun addButton(root: LinearLayout, text: String, action: () -> Unit) {
        root.addView(Button(this).apply { this.text = text; setOnClickListener { action() } }, matchWidth())
    }

    private fun matchWidth() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    private fun loadFields() {
        val c = ConfigStore.load(this)
        tokenInput.setText(c.botToken)
        chatInput.setText(c.chatId)
        videoInput.setText(c.premiumVideoUrl)
        apiInput.setText(c.apiUrl)
    }

    private fun saveFields() {
        ConfigStore.save(this, AppConfig(
            tokenInput.text.toString().trim(),
            chatInput.text.toString().trim(),
            videoInput.text.toString().trim(),
            apiInput.text.toString().trim()
        ))
    }

    private fun requestPermissionAndStart() {
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES else Manifest.permission.READ_EXTERNAL_STORAGE
        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) startBackup()
        else permissionLauncher.launch(permission)
    }

    private fun startBackup() {
        val c = ConfigStore.load(this)
        if (c.botToken.isBlank() || c.chatId.isBlank() ||
            c.botToken == "ADD_BOT_TOKEN_HERE" || c.chatId == "ADD_CHANNEL_ID_HERE") {
            statusText.text = "Bot Token ও Channel ID সেটিংসে দিন অথবা XX.json লোড করুন।"
            return
        }
        val constraints = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
        val request = OneTimeWorkRequestBuilder<BackupWorker>().setConstraints(constraints).build()
        WorkManager.getInstance(this).enqueueUniqueWork("gallery_backup", ExistingWorkPolicy.KEEP, request)
        statusText.text = "ব্যাকআপ কিউতে যোগ হয়েছে। ইন্টারনেট থাকলে আপলোড হবে।"
    }

    private fun refreshStatus() {
        if (!::statusText.isInitialized) return
        statusText.text = getSharedPreferences("backup_state", MODE_PRIVATE)
            .getString("last_status", "এখনও ব্যাকআপ চালানো হয়নি.") ?: "এখনও ব্যাকআপ চালানো হয়নি."
    }

    override fun onResume() {
        super.onResume()
        if (::statusText.isInitialized) refreshStatus()
    }
}
