package com.riyan.gallerybackup

import android.content.Context
import android.net.Uri
import org.json.JSONObject

data class AppConfig(
    val botToken: String = "",
    val chatId: String = "",
    val premiumVideoUrl: String = "",
    val apiUrl: String = ""
)

object ConfigStore {
    private const val PREFS = "gallery_config"
    private const val KEY_JSON = "config_json"

    fun load(context: Context): AppConfig {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_JSON, null) ?: readAsset(context)
        return parse(raw)
    }

    fun readAsset(context: Context): String {
        return try {
            context.assets.open("XX.json").bufferedReader().use { it.readText() }
        } catch (_: Exception) { "{}" }
    }

    fun importJson(context: Context, uri: Uri): String {
        val raw = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
            ?: throw IllegalStateException("ফাইলটি পড়া যায়নি")
        val config = parse(raw)
        if (config.botToken.isBlank() || config.chatId.isBlank()) {
            throw IllegalArgumentException("XX.json-এ bot_token ও channel_id পূরণ করুন")
        }
        JSONObject(raw) // validate JSON
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_JSON, raw).apply()
        return "XX.json লোড হয়েছে।"
    }

    fun save(context: Context, config: AppConfig) {
        val obj = JSONObject()
            .put("bot_token", config.botToken)
            .put("channel_id", config.chatId)
            .put("premium_video_url", config.premiumVideoUrl)
            .put("api_url", config.apiUrl)
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_JSON, obj.toString(2)).apply()
    }

    private fun parse(raw: String): AppConfig {
        return try {
            val o = JSONObject(raw)
            AppConfig(
                botToken = o.optString("bot_token", ""),
                chatId = o.optString("channel_id", ""),
                premiumVideoUrl = o.optString("premium_video_url", ""),
                apiUrl = o.optString("api_url", "")
            )
        } catch (_: Exception) { AppConfig() }
    }
}
