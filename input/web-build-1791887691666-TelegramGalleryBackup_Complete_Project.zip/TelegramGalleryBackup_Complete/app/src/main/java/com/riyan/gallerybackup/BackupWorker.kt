package com.riyan.gallerybackup

import android.content.ContentUris
import android.content.Context
import android.provider.MediaStore
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit

class BackupWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    private val client = OkHttpClient.Builder()
        .callTimeout(3, TimeUnit.MINUTES)
        .build()

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val config = ConfigStore.load(applicationContext)
        if (config.botToken.isBlank() || config.chatId.isBlank() ||
            config.botToken == "ADD_BOT_TOKEN_HERE" || config.chatId == "ADD_CHANNEL_ID_HERE") {
            BackupState.set(applicationContext, "XX.json-এ Bot Token ও Channel ID সেট করুন।")
            return@withContext Result.failure()
        }

        val prefs = applicationContext.getSharedPreferences("backup_state", Context.MODE_PRIVATE)
        val sent = prefs.getStringSet("sent_media_ids", emptySet())?.toMutableSet() ?: mutableSetOf()
        val failedNames = mutableListOf<String>()
        var uploadedThisRun = 0
        var failedThisRun = 0
        var scanned = 0

        val collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.MIME_TYPE,
            MediaStore.Images.Media.SIZE
        )
        val sort = "${MediaStore.Images.Media.DATE_ADDED} ASC"

        applicationContext.contentResolver.query(collection, projection, null, null, sort)?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
            val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.MIME_TYPE)
            val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)

            while (cursor.moveToNext()) {
                if (isStopped) return@withContext Result.retry()
                scanned++
                val id = cursor.getLong(idCol)
                val name = cursor.getString(nameCol) ?: "image_$id"
                val mime = cursor.getString(mimeCol) ?: "application/octet-stream"
                val size = cursor.getLong(sizeCol)
                val key = id.toString()
                if (sent.contains(key)) continue

                if (size > 48L * 1024 * 1024) {
                    failedThisRun++
                    failedNames.add("$name (ফাইল বড়)")
                    continue
                }

                BackupState.set(applicationContext,
                    "স্ক্যান: $scanned\nআপলোড হচ্ছে: $name\nএই রানে সফল: $uploadedThisRun | ব্যর্থ: $failedThisRun")

                val uri = ContentUris.withAppendedId(collection, id)
                val temp = File(applicationContext.cacheDir, "backup_${id}_${System.currentTimeMillis()}")
                try {
                    applicationContext.contentResolver.openInputStream(uri).use { input ->
                        if (input == null) throw IllegalStateException("ফাইল পড়া যায়নি")
                        FileOutputStream(temp).use { output -> input.copyTo(output) }
                    }

                    val body = MultipartBody.Builder().setType(MultipartBody.FORM)
                        .addFormDataPart("chat_id", config.chatId)
                        .addFormDataPart("document", name, temp.asRequestBody(mime.toMediaTypeOrNull()))
                        .build()
                    val request = Request.Builder()
                        .url("https://api.telegram.org/bot${config.botToken}/sendDocument")
                        .post(body).build()

                    client.newCall(request).execute().use { response ->
                        val responseText = response.body?.string().orEmpty()
                        if (!response.isSuccessful || !responseText.contains("\"ok\":true")) {
                            throw IllegalStateException("Telegram API error: HTTP ${response.code}")
                        }
                    }
                    sent.add(key)
                    prefs.edit().putStringSet("sent_media_ids", sent).apply()
                    uploadedThisRun++
                } catch (e: Exception) {
                    failedThisRun++
                    failedNames.add(name)
                } finally {
                    temp.delete()
                }
            }
        }

        prefs.edit()
            .putInt("last_success_count", uploadedThisRun)
            .putInt("last_failed_count", failedThisRun)
            .putInt("last_scanned_count", scanned)
            .putString("last_failed_names", failedNames.take(30).joinToString("\n"))
            .apply()

        BackupState.set(applicationContext,
            "এই রানে স্ক্যান করা: $scanned\nসফল আপলোড: $uploadedThisRun\nব্যর্থ: $failedThisRun\n" +
            if (failedNames.isEmpty()) "সব নতুন ছবি পাঠানোর চেষ্টা শেষ।" else "ব্যর্থ ফাইল:\n${failedNames.take(10).joinToString("\n")}")
        Result.success()
    }
}

object BackupState {
    fun set(context: Context, value: String) {
        context.getSharedPreferences("backup_state", Context.MODE_PRIVATE)
            .edit().putString("last_status", value).apply()
    }
}
