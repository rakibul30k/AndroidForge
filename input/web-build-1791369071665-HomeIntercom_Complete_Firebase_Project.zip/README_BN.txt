HOME INTERCOM — TWO-WAY BACKGROUND VERSION

এটা আপনার চাওয়া final architecture:
- একই APK দুই ফোনে
- একবার Room Code দিয়ে connect
- দুই ফোনের microphone + speaker
- WebRTC live two-way audio
- Foreground Service-এর মাধ্যমে screen বন্ধ/অ্যাপ background-এ রেখেও চালানোর চেষ্টা
- Android notification থাকবে, কারণ microphone background access-এর জন্য Android foreground service প্রয়োজন।

Firebase:
আপনার দেওয়া Firebase project-এর config ইতিমধ্যে web version-এ ছিল। Android build-এর জন্য Firebase Console থেকে এই Android app-এর package:
com.homeintercom
যোগ করে google-services.json ডাউনলোড করে app/ folder-এ রাখতে হবে।

Realtime Database Rules পরীক্ষার জন্য:
{
  "rules": {
    "homeIntercomV2": {
      ".read": true,
      ".write": true
    }
  }
}
এগুলো production-এর জন্য নিরাপদ নয়; শুধু নিজের পরীক্ষার জন্য ব্যবহার করুন। পরে Authentication দিয়ে rules lock করা উচিত।

ব্যবহার:
1. প্রথম ফোনে app খুলে ৬ সংখ্যার Room Code দিন → প্রথম ফোন → CONNECT।
2. দ্বিতীয় ফোনে একই Code → দ্বিতীয় ফোন → CONNECT।
3. দুই ফোনেই Microphone permission দিন।
4. Connection হলে কথা বললে অপর ফোনে শোনা যাবে।
5. Disconnect না করা পর্যন্ত service চালু রাখার জন্য notification থাকবে।

Android 14+:
Microphone foreground service শুরু করতে app-টি visible থাকা অবস্থায় permission নিয়ে Connect চাপতে হবে। Android background থেকে নতুন microphone foreground service শুরু করতে বাধা দেয়।
