package com.homeintercom;

import android.Manifest;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.view.View;
import android.widget.*;
import java.util.*;

public class MainActivity extends android.app.Activity {
    EditText roomCode; TextView status; RadioGroup roleGroup;
    static final int MIC=10;
    @Override public void onCreate(Bundle b){
        super.onCreate(b); setContentView(R.layout.activity_main);
        roomCode=findViewById(R.id.roomCode); status=findViewById(R.id.status); roleGroup=findViewById(R.id.roleGroup);
        String saved=getSharedPreferences("intercom",0).getString("room","");
        if(!saved.isEmpty()) roomCode.setText(saved);

        findViewById(R.id.connect).setOnClickListener(v -> connect());
        findViewById(R.id.disconnect).setOnClickListener(v -> {
            stopService(new Intent(this, IntercomService.class));
            status.setText("Disconnected");
        });
    }
    void connect(){
        String room=roomCode.getText().toString().trim();
        if(room.length()!=6){ roomCode.setError("৬ সংখ্যার কোড দিন"); return; }
        getSharedPreferences("intercom",0).edit().putString("room",room).apply();
        if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC); return;
        }
        start(room);
    }
    void start(String room){
        boolean host=((RadioButton)findViewById(R.id.host)).isChecked();
        Intent i=new Intent(this,IntercomService.class);
        i.putExtra("room",room); i.putExtra("host",host);
        if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i);
        status.setText("🟢 Intercom চালু — এখন অ্যাপ বন্ধ করলেও চলবে");
    }
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){
        super.onRequestPermissionsResult(r,p,g);
        if(r==MIC && g.length>0 && g[0]==PackageManager.PERMISSION_GRANTED) connect();
        else status.setText("Microphone permission প্রয়োজন");
    }
}
