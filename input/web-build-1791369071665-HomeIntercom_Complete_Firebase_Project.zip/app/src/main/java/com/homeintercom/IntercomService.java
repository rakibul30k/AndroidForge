package com.homeintercom;

import android.app.*;
import android.content.*;
import android.media.*;
import android.os.*;
import androidx.annotation.Nullable;

import com.google.firebase.database.*;
import org.webrtc.*;
import java.util.*;

public class IntercomService extends Service {
    static final String CH="intercom_channel";
    String room; boolean host;
    DatabaseReference ref;
    PeerConnectionFactory factory;
    PeerConnection pc;
    AudioSource audioSource;
    AudioTrack audioTrack;
    AudioManager audioManager;
    Handler handler=new Handler(Looper.getMainLooper());

    private final PeerConnection.IceServer STUN =
        PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer();

    @Override public void onCreate(){
        super.onCreate();
        createNotificationChannel();
        startForeground(99, notification("Intercom starting…"),
            Build.VERSION.SDK_INT>=29 ? ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE : 0);
        audioManager=(AudioManager)getSystemService(AUDIO_SERVICE);
        audioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
        audioManager.setSpeakerphoneOn(true);
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(this).createInitializationOptions());
        factory=PeerConnectionFactory.builder().createPeerConnectionFactory();
    }

    @Override public int onStartCommand(Intent i,int flags,int startId){
        if(i!=null){
            room=i.getStringExtra("room"); host=i.getBooleanExtra("host",true);
            if(room!=null) handler.post(this::connect);
        }
        return START_STICKY;
    }

    void connect(){
        if(room==null || factory==null) return;
        if(pc!=null) pc.close();
        ref=FirebaseDatabase.getInstance().getReference("homeIntercomV2/rooms/"+room);

        AudioSource as=factory.createAudioSource(new MediaConstraints());
        audioSource=as;
        audioTrack=factory.createAudioTrack("audio0",as);
        audioTrack.setEnabled(true);

        PeerConnection.RTCConfiguration cfg=new PeerConnection.RTCConfiguration(
            Collections.singletonList(STUN));
        cfg.sdpSemantics=PeerConnection.SdpSemantics.UNIFIED_PLAN;
        pc=factory.createPeerConnection(cfg,new Observer());

        pc.addTrack(audioTrack);

        if(host) createOffer(); else waitForOffer();
    }

    void createOffer(){
        MediaConstraints c=new MediaConstraints();
        pc.createOffer(new SdpObserverAdapter(){
            public void onCreateSuccess(SessionDescription s){
                pc.setLocalDescription(new SdpObserverAdapter(),s);
                Map<String,Object> m=new HashMap<>();
                m.put("type",s.type.canonicalForm()); m.put("sdp",s.description);
                ref.child("offer").setValue(m);
            }
        },c);
        listenForAnswer();
        listenForCandidates("answerCandidates");
    }

    void waitForOffer(){
        ref.child("offer").addListenerForSingleValueEvent(new ValueEventListener(){
            public void onDataChange(DataSnapshot s){
                if(!s.exists()) { postReconnect(); return; }
                String type=s.child("type").getValue(String.class);
                String desc=s.child("sdp").getValue(String.class);
                if(desc==null){postReconnect();return;}
                pc.setRemoteDescription(new SdpObserverAdapter(),
                    new SessionDescription(SessionDescription.Type.fromCanonicalForm(type),desc));
                pc.createAnswer(new SdpObserverAdapter(){
                    public void onCreateSuccess(SessionDescription a){
                        pc.setLocalDescription(new SdpObserverAdapter(),a);
                        Map<String,Object> m=new HashMap<>();
                        m.put("type",a.type.canonicalForm());m.put("sdp",a.description);
                        ref.child("answer").setValue(m);
                    }
                },new MediaConstraints());
                listenForCandidates("offerCandidates");
            }
            public void onCancelled(DatabaseError e){postReconnect();}
        });
    }

    void listenForAnswer(){
        ref.child("answer").addValueEventListener(new ValueEventListener(){
            public void onDataChange(DataSnapshot s){
                if(pc==null || pc.getRemoteDescription()!=null || !s.exists()) return;
                String d=s.child("sdp").getValue(String.class);
                String t=s.child("type").getValue(String.class);
                if(d!=null) pc.setRemoteDescription(new SdpObserverAdapter(),
                    new SessionDescription(SessionDescription.Type.fromCanonicalForm(t),d));
            }
            public void onCancelled(DatabaseError e){}
        });
    }

    void listenForCandidates(String node){
        ref.child(node).addChildEventListener(new ChildEventListener(){
            public void onChildAdded(DataSnapshot s, String prev){
                String cand=s.child("candidate").getValue(String.class);
                String mid=s.child("sdpMid").getValue(String.class);
                Long idx=s.child("sdpMLineIndex").getValue(Long.class);
                if(cand!=null && idx!=null && pc!=null)
                    pc.addIceCandidate(new IceCandidate(mid,idx.intValue(),cand));
            }
            public void onChildChanged(DataSnapshot s,String p){} public void onChildRemoved(DataSnapshot s){}
            public void onChildMoved(DataSnapshot s,String p){} public void onCancelled(DatabaseError e){}
        });
    }

    class Observer implements PeerConnection.Observer{
        public void onIceCandidate(IceCandidate c){
            String node=host?"offerCandidates":"answerCandidates";
            Map<String,Object> m=new HashMap<>();
            m.put("candidate",c.sdp);m.put("sdpMid",c.sdpMid);m.put("sdpMLineIndex",c.sdpMLineIndex);
            ref.child(node).push().setValue(m);
        }
        public void onConnectionChange(PeerConnection.PeerConnectionState s){
            if(s==PeerConnection.PeerConnectionState.FAILED ||
               s==PeerConnection.PeerConnectionState.DISCONNECTED) postReconnect();
        }
        public void onTrack(RtpTransceiver t){ }
        public void onAddStream(MediaStream s){}
        public void onDataChannel(DataChannel d){}
        public void onSignalingChange(PeerConnection.SignalingState s){}
        public void onIceConnectionChange(PeerConnection.IceConnectionState s){}
        public void onIceConnectionReceivingChange(boolean b){}
        public void onIceGatheringChange(PeerConnection.IceGatheringState s){}
        public void onIceCandidatesRemoved(IceCandidate[] c){}
        public void onRemoveStream(MediaStream s){}
        public void onRenegotiationNeeded(){}
        public void onSelectedCandidatePairChanged(CandidatePairChangeEvent e){}
        public void onStandardizedIceConnectionChange(PeerConnection.IceConnectionState s){}
        public void onConnectionReceivingChange(boolean b){}
    }

    void postReconnect(){ handler.postDelayed(this::connect,3000); }

    static class SdpObserverAdapter implements SdpObserver{
        public void onCreateSuccess(SessionDescription s){}
        public void onSetSuccess(){}
        public void onCreateFailure(String s){}
        public void onSetFailure(String s){}
    }

    Notification notification(String text){
        Intent i=new Intent(this,MainActivity.class);
        PendingIntent pi=PendingIntent.getActivity(this,0,i,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this,CH).setContentTitle("Home Intercom")
            .setContentText(text).setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true).setContentIntent(pi).build();
    }
    void createNotificationChannel(){
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel c=new NotificationChannel(CH,"Home Intercom",NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }
    @Override public void onDestroy(){
        if(pc!=null)pc.close(); if(audioSource!=null)audioSource.dispose();
        if(factory!=null)factory.dispose();
        if(audioManager!=null){audioManager.setSpeakerphoneOn(false);audioManager.setMode(AudioManager.MODE_NORMAL);}
        super.onDestroy();
    }
    @Nullable public android.os.IBinder onBind(Intent i){return null;}
}
