RIYAN HOME INTERCOM — Fresh Android project

- Same Room Code on two phones
- Explicit microphone permission
- Foreground microphone service
- WebRTC two-way audio
- Firebase Realtime Database signaling
- Visible ongoing notification while active

Firebase RTDB path: homeIntercomV2/rooms/{room}
The current Firebase rules must allow this path for testing.
This project intentionally does not use the Google Services Gradle plugin; Firebase is initialized directly from the supplied project configuration to reduce build-tool dependencies.
