package com.riyan.homeintercom;

import android.app.*;import android.content.*;import android.media.AudioManager;import android.os.*;import androidx.core.app.NotificationCompat;
import com.google.firebase.database.*;
import org.webrtc.*;import java.util.*;import java.util.concurrent.atomic.AtomicBoolean;

public class IntercomService extends Service {
    static final String CH="riyan_intercom"; DatabaseReference root,me,other; String room,role; PeerConnection pc; PeerConnectionFactory factory; AudioSource source; AudioTrack local; final ArrayList<IceCandidate> pendingCandidates=new ArrayList<>(); final AtomicBoolean started=new AtomicBoolean(false); Handler h=new Handler(Looper.getMainLooper());
    @Override public void onCreate(){super.onCreate(); createChannel();}
    void createChannel(){NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE); if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(new NotificationChannel(CH,"Home Intercom",NotificationManager.IMPORTANCE_LOW));}
    Notification notification(){return new NotificationCompat.Builder(this,CH).setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentTitle("RIYAN HOME INTERCOM").setContentText(role==null?"Intercom":"Intercom • "+role).setOngoing(true).build();}
    @Override public int onStartCommand(Intent i,int flags,int id){ if(i!=null){room=i.getStringExtra("room");role=i.getStringExtra("role");} if(Build.VERSION.SDK_INT>=29){ int type=role!=null && role.equals("talker") ? android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE : android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK; startForeground(7,notification(),type); } else startForeground(7,notification()); if(!started.getAndSet(true)) init(); return START_STICKY; }
    void init(){
        root=FirebaseDatabase.getInstance("https://fast-pay-5efbb-default-rtdb.firebaseio.com").getReference("homeIntercomV2").child("rooms").child(safe(room));
        me=root.child(role); other=root.child(role.equals("talker")?"listener":"talker");
        setupAudio(); setupPeer(); listenSignaling(); if(role.equals("talker")) createOffer();
    }
    String safe(String s){return s.replace(".","_").replace("#","_").replace("$","_").replace("[","_").replace("]","_").replace("/","_");}
    void setupAudio(){ AudioManager am=(AudioManager)getSystemService(AUDIO_SERVICE); am.setMode(AudioManager.MODE_IN_COMMUNICATION); am.setSpeakerphoneOn(true);
        PeerConnectionFactory.initialize(PeerConnectionFactory.InitializationOptions.builder(this).setEnableInternalTracer(false).createInitializationOptions());
        JavaAudioDeviceModule adm=JavaAudioDeviceModule.builder(this).setUseHardwareAcousticEchoCanceler(false).setUseHardwareNoiseSuppressor(false).createAudioDeviceModule();
        factory=PeerConnectionFactory.builder().setAudioDeviceModule(adm).createPeerConnectionFactory();
        if(role.equals("talker")){source=factory.createAudioSource(new MediaConstraints());local=factory.createAudioTrack("riyan-audio",source);local.setEnabled(true);}
    }
    void setupPeer(){ List<PeerConnection.IceServer> ice=Collections.singletonList(PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer()); PeerConnection.RTCConfiguration cfg=new PeerConnection.RTCConfiguration(ice); cfg.sdpSemantics=PeerConnection.SdpSemantics.UNIFIED_PLAN;
        pc=factory.createPeerConnection(cfg,new PeerConnection.Observer(){
            public void onSignalingChange(PeerConnection.SignalingState s){} public void onIceConnectionChange(PeerConnection.IceConnectionState s){} public void onIceConnectionReceivingChange(boolean b){} public void onIceGatheringChange(PeerConnection.IceGatheringState s){} public void onIceCandidate(IceCandidate c){me.child("ice").push().setValue(candidate(c));} public void onIceCandidatesRemoved(IceCandidate[] c){} public void onAddStream(MediaStream s){} public void onRemoveStream(MediaStream s){} public void onDataChannel(DataChannel d){} public void onRenegotiationNeeded(){} public void onConnectionChange(PeerConnection.PeerConnectionState s){}
            public void onTrack(RtpTransceiver t){ MediaStreamTrack tr=t.getReceiver().track(); if(tr instanceof AudioTrack)((AudioTrack)tr).setEnabled(true); }
        }); if(pc==null)throw new IllegalStateException("PeerConnection create failed"); if(local!=null)pc.addTrack(local,Collections.singletonList("audio")); }
    Map<String,Object> candidate(IceCandidate c){Map<String,Object>m=new HashMap<>();m.put("sdpMid",c.sdpMid);m.put("sdpMLineIndex",c.sdpMLineIndex);m.put("candidate",c.sdp);return m;}
    void listenSignaling(){ other.child("ice").addChildEventListener(new ChildEventListener(){public void onChildAdded(DataSnapshot s,String prev){Map v=(Map)s.getValue();if(v!=null){ Object idx=v.get("sdpMLineIndex"); int n=idx instanceof Number?((Number)idx).intValue():0; IceCandidate c=new IceCandidate((String)v.get("sdpMid"),n,(String)v.get("candidate")); if(pc.getRemoteDescription()==null) pendingCandidates.add(c); else pc.addIceCandidate(c); }}public void onChildChanged(DataSnapshot s,String p){}public void onChildRemoved(DataSnapshot s){}public void onChildMoved(DataSnapshot s,String p){}public void onCancelled(DatabaseError e){}});
        other.child("offer").addValueEventListener(new ValueEventListener(){public void onDataChange(DataSnapshot s){if(!role.equals("listener")||!s.exists())return; Map v=(Map)s.getValue(); String sd=(String)v.get("sdp"); if(pc.getRemoteDescription()==null)pc.setRemoteDescription(new SimpleSdpObserver(){public void onSetSuccess(){ for(IceCandidate c:pendingCandidates) pc.addIceCandidate(c); pendingCandidates.clear(); createAnswer(); }},new SessionDescription(SessionDescription.Type.OFFER,sd));}public void onCancelled(DatabaseError e){}});
        other.child("answer").addValueEventListener(new ValueEventListener(){public void onDataChange(DataSnapshot s){if(!role.equals("talker")||!s.exists())return;Map v=(Map)s.getValue();String sd=(String)v.get("sdp");if(pc.getRemoteDescription()==null)pc.setRemoteDescription(new SimpleSdpObserver(){},new SessionDescription(SessionDescription.Type.ANSWER,sd));}public void onCancelled(DatabaseError e){}});
    }
    void createOffer(){pc.createOffer(new SimpleSdpObserver(){public void onCreateSuccess(SessionDescription d){pc.setLocalDescription(new SimpleSdpObserver(){public void onSetSuccess(){Map<String,Object>m=new HashMap<>();m.put("sdp",d.description);me.child("offer").setValue(m);}},d);}},new MediaConstraints());}
    void createAnswer(){pc.createAnswer(new SimpleSdpObserver(){public void onCreateSuccess(SessionDescription d){pc.setLocalDescription(new SimpleSdpObserver(){public void onSetSuccess(){Map<String,Object>m=new HashMap<>();m.put("sdp",d.description);me.child("answer").setValue(m);}},d);}},new MediaConstraints());}
    static class SimpleSdpObserver implements SdpObserver{public void onCreateSuccess(SessionDescription d){}public void onSetSuccess(){}public void onCreateFailure(String s){}public void onSetFailure(String s){}}
    @Override public void onDestroy(){try{if(root!=null)root.removeValue();}catch(Exception ignored){}try{if(pc!=null)pc.close();if(factory!=null)factory.dispose();}catch(Exception ignored){}AudioManager am=(AudioManager)getSystemService(AUDIO_SERVICE);am.setMode(AudioManager.MODE_NORMAL);am.setSpeakerphoneOn(false);super.onDestroy();}
    @Override public android.os.IBinder onBind(Intent i){return null;}
}
