package com.riyan.homeintercom;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.*;
import androidx.activity.ComponentActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends ComponentActivity {
    EditText room; RadioGroup roles; TextView status; final int REQ=41;
    @Override public void onCreate(Bundle b){ super.onCreate(b); setContentView(R.layout.activity_main);
        room=findViewById(R.id.roomCode); roles=findViewById(R.id.roleGroup); status=findViewById(R.id.status);
        room.setText(getPreferences(0).getString("room",""));
        ((Button)findViewById(R.id.connect)).setOnClickListener(v -> start());
        ((Button)findViewById(R.id.disconnect)).setOnClickListener(v -> { stopService(new Intent(this,IntercomService.class)); status.setText("সংযোগ বন্ধ"); });
    }
    void start(){ String r=room.getText().toString().trim(); if(r.length()<3){room.setError("কমপক্ষে 3 অক্ষরের room code দিন");return;}
        getPreferences(0).edit().putString("room",r).apply();
        boolean talker=((RadioButton)findViewById(R.id.talker)).isChecked();
        if(talker && ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.RECORD_AUDIO},REQ);return;}
        if(Build.VERSION.SDK_INT>=33 && ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.POST_NOTIFICATIONS},REQ+1);}
        launch(r);
    }
    void launch(String r){ boolean talker=((RadioButton)findViewById(R.id.talker)).isChecked(); Intent i=new Intent(this,IntercomService.class).putExtra("room",r).putExtra("role",talker?"talker":"listener"); ContextCompat.startForegroundService(this,i); status.setText(talker?"Talker চালু — কথা বলুন":"Listener চালু — এখন অন্য ফোন থেকে বললে শুনবেন"); }
    @Override public void onRequestPermissionsResult(int q,String[] p,int[] g){super.onRequestPermissionsResult(q,p,g); if(q==REQ && g.length>0 && g[0]==PackageManager.PERMISSION_GRANTED) start();}
}
