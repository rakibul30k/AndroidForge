# RIYAN HOME INTERCOM

A consent-based Android room intercom using Firebase Realtime Database signaling and WebRTC audio.

## Use
1. Install the same APK on two phones.
2. Choose the same room code on both.
3. On the listening phone choose **Listener** and tap **একবার চালু করুন**. Keep the foreground-service notification enabled.
4. On the speaking phone choose **Talker** and tap **একবার চালু করুন**.
5. The Listener phone plays incoming audio automatically; it does not need to be opened again while Android keeps the foreground service running.

This is an explicit microphone/speaker intercom. Android may stop background services after force-stop or aggressive OEM battery management. STUN is included; some restrictive networks may require a TURN server.
