# OneApp Backup + YouTube + Basic Ad Blocking

এই Android Studio source project-এ এক APK-তে:
- WebView-এ YouTube/কাস্টম URL খোলা
- কয়েকটি পরিচিত ad/tracker host ব্লক করার চেষ্টা
- Telegram Bot API দিয়ে MediaStore-এর ছবি ও ভিডিও `sendDocument` হিসেবে ব্যাকআপ
- `XX.json` ইমপোর্ট/এক্সপোর্ট, তাই MT Manager দিয়ে JSON সম্পাদনা করে অ্যাপে ইমপোর্ট করা যায়
- WorkManager দিয়ে ঐচ্ছিক নেটওয়ার্ক-নির্ভর periodic backup

## গুরুত্বপূর্ণ সীমাবদ্ধতা
1. **এটি source project, APK নয়; এখানে build বা বাস্তব ডিভাইসে test করা হয়নি।** তাই “কোনো ভুল নেই” বলে নিশ্চয়তা দেওয়া সৎ হবে না। Android Studio-তে build ও বাস্তব ফোনে পরীক্ষা দরকার।
2. WebView/DNS নয়—এই অ্যাপের ad blocker কেবল WebView request-এর কিছু host আটকায়। YouTube-এর সব video ad ব্লক হবে না; YouTube পরিবর্তন করলে আরও কম কাজ করতে পারে। কিছু সাইট/ভিডিও ভেঙেও যেতে পারে।
3. Telegram Bot API-র ফাইল-সীমা/অ্যাকাউন্ট সীমা বদলাতে পারে। এই starter code 49 MB-এর বড় media ফাইল skip করে। Telegram bot-কে target channel/group-এ যোগ করে পোস্ট করার অনুমতি দিতে হবে।
4. Android-এর battery optimization/force-stop/background restrictions অটো ব্যাকআপ দেরি করাতে পারে। WorkManager ১৫ মিনিটের বেশি ব্যবধানে best-effort; একেবারে তাৎক্ষণিক নয়।
5. Telegram token অ্যাপ বা JSON-এ থাকলে বের করা সম্ভব। কেবল নিজের bot ব্যবহার করুন; নিরাপদ উৎপাদন-ব্যবস্থায় token backend-এ রাখা ভালো।
6. Android 13+ এ ছবি এবং ভিডিও—দুই permission দিতে হবে। Partial media access-এ ব্যবহারকারী সীমিত নির্বাচন করলে সব মিডিয়া দেখা নাও যেতে পারে।
7. YouTube sign-in/playback কিছু WebView-এ সীমিত হতে পারে; Google/YouTube-এর নীতিমালা এবং playback restrictions প্রযোজ্য।

## Build
- Android Studio-তে এই folder open করুন।
- Gradle sync সম্পূর্ণ হতে দিন (ইন্টারনেট দরকার)।
- Build > Build APK(s)।
- APK ইনস্টল করে Permissions দিন, Settings-এ Bot Token এবং Channel ID বসান।
- MT Manager-এ JSON সম্পাদনা করলে Settings > “MT Manager দিয়ে সম্পাদিত XX.json ইমপোর্ট” দিয়ে পুনরায় লোড করুন।

## XX.json example
```json
{
  "bot_token": "YOUR_TELEGRAM_BOT_TOKEN",
  "channel_id": "-1001234567890",
  "youtube_url": "https://m.youtube.com/",
  "start_url": "https://m.youtube.com/",
  "adblock_filter_url": "",
  "adblock_enabled": true,
  "auto_backup": false
}
```
