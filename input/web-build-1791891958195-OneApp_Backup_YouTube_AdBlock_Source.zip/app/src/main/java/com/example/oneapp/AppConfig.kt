package com.example.oneapp

import android.content.Context
import org.json.JSONObject

data class AppConfig(
    val botToken: String = "",
    val channelId: String = "",
    val youtubeUrl: String = "https://m.youtube.com/",
    val startUrl: String = "https://m.youtube.com/",
    val adblockFilterUrl: String = "",
    val adblockEnabled: Boolean = true,
    val autoBackup: Boolean = false
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("bot_token", botToken)
        put("channel_id", channelId)
        put("youtube_url", youtubeUrl)
        put("start_url", startUrl)
        put("adblock_filter_url", adblockFilterUrl)
        put("adblock_enabled", adblockEnabled)
        put("auto_backup", autoBackup)
    }

    companion object {
        private const val PREFS = "oneapp_config"
        private const val KEY_JSON = "config_json"

        fun load(context: Context): AppConfig {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val raw = prefs.getString(KEY_JSON, null) ?: runCatching {
                context.assets.open("XX.json").bufferedReader().use { it.readText() }
            }.getOrDefault("{}")
            return parse(raw)
        }

        fun save(context: Context, config: AppConfig) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(KEY_JSON, config.toJson().toString()).apply()
        }

        fun parse(raw: String): AppConfig {
            val j = JSONObject(raw)
            return AppConfig(
                botToken = j.optString("bot_token", ""),
                channelId = j.optString("channel_id", ""),
                youtubeUrl = safeWebUrl(j.optString("youtube_url", "https://m.youtube.com/")),
                startUrl = safeWebUrl(j.optString("start_url", j.optString("youtube_url", "https://m.youtube.com/"))),
                adblockFilterUrl = safeWebUrlAllowBlank(j.optString("adblock_filter_url", "")),
                adblockEnabled = j.optBoolean("adblock_enabled", true),
                autoBackup = j.optBoolean("auto_backup", false)
            )
        }

        fun safeWebUrl(raw: String): String {
            val s = raw.trim()
            return if (s.startsWith("https://", true) || s.startsWith("http://", true)) s
            else "https://m.youtube.com/"
        }

        fun safeWebUrlAllowBlank(raw: String): String {
            val s = raw.trim()
            return if (s.isEmpty() || s.startsWith("https://", true) || s.startsWith("http://", true)) s else ""
        }
    }
}
