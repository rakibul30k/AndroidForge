package com.example.oneapp

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.DataOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

class TelegramBackupWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val cfg = AppConfig.load(applicationContext)
        if (cfg.botToken.isBlank() || cfg.channelId.isBlank() ||
            cfg.botToken.contains("PASTE_YOUR") || cfg.channelId.contains("PASTE_YOUR")) {
            return@withContext Result.failure()
        }

        val prefs = applicationContext.getSharedPreferences("backup_state", Context.MODE_PRIVATE)
        val sent = prefs.getStringSet("sent_media_ids", emptySet())?.toMutableSet() ?: mutableSetOf()
        var successes = 0
        var failures = 0
        val media = MediaStore.Files.getContentUri("external")
        val projection = arrayOf(MediaStore.Files.FileColumns._ID, MediaStore.Files.FileColumns.MIME_TYPE,
            MediaStore.Files.FileColumns.DISPLAY_NAME, MediaStore.Files.FileColumns.SIZE)
        val selection = "(${MediaStore.Files.FileColumns.MEDIA_TYPE}=? OR ${MediaStore.Files.FileColumns.MEDIA_TYPE}=?)"
        val args = arrayOf(
            MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE.toString(),
            MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO.toString()
        )
        val sort = "${MediaStore.Files.FileColumns.DATE_ADDED} ASC"
        applicationContext.contentResolver.query(media, projection, selection, args, sort)?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID)
            val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MIME_TYPE)
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DISPLAY_NAME)
            val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.SIZE)
            var processed = 0
            while (cursor.moveToNext() && processed < 5 && !isStopped) {
                val id = cursor.getLong(idCol)
                val key = id.toString()
                if (key in sent) continue
                val size = cursor.getLong(sizeCol)
                // Bot API upload size limits and device data usage: skip files over 49 MB.
                if (size > 49L * 1024L * 1024L) continue
                val uri = ContentUris.withAppendedId(media, id)
                val mime = cursor.getString(mimeCol) ?: "application/octet-stream"
                val name = cursor.getString(nameCol)?.takeIf { it.isNotBlank() } ?: "media_$id"
                val ok = upload(uri, mime, name, cfg.botToken, cfg.channelId)
                if (ok) {
                    sent.add(key)
                    successes++
                } else {
                    failures++
                }
                processed++
            }
        }
        prefs.edit().putStringSet("sent_media_ids", sent).apply()
        prefs.edit().putLong("last_run", System.currentTimeMillis())
            .putInt("last_success_count", successes)
            .putInt("last_failure_count", failures).apply()
        if (failures > 0 && successes == 0) Result.retry() else Result.success()
    }

    private fun upload(uri: Uri, mime: String, fileName: String, token: String, chatId: String): Boolean {
        val boundary = "----OneApp${UUID.randomUUID()}"
        var conn: HttpURLConnection? = null
        return try {
            conn = (URL("https://api.telegram.org/bot$token/sendDocument").openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                connectTimeout = 20000
                readTimeout = 30000
                setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            }
            DataOutputStream(conn.outputStream).use { out ->
                fun field(name: String, value: String) {
                    out.writeBytes("--$boundary\r\n")
                    out.writeBytes("Content-Disposition: form-data; name=\"$name\"\r\n\r\n")
                    out.write(value.toByteArray(Charsets.UTF_8))
                    out.writeBytes("\r\n")
                }
                field("chat_id", chatId)
                out.writeBytes("--$boundary\r\n")
                out.writeBytes("Content-Disposition: form-data; name=\"document\"; filename=\"${fileName.replace("\"", "_")}\"\r\n")
                out.writeBytes("Content-Type: $mime\r\n\r\n")
                applicationContext.contentResolver.openInputStream(uri)?.use { input ->
                    val buffer = ByteArray(64 * 1024)
                    while (true) {
                        val n = input.read(buffer)
                        if (n <= 0) break
                        out.write(buffer, 0, n)
                    }
                } ?: return false
                out.writeBytes("\r\n--$boundary--\r\n")
            }
            conn.responseCode in 200..299 &&
                conn.inputStream.bufferedReader().use { it.readText() }.contains("\"ok\":true")
        } catch (_: Exception) {
            false
        } finally {
            conn?.disconnect()
        }
    }
}
