package com.example.oneapp

import android.content.Context
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

object AdBlocker {
    private val builtInHosts = setOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "adservice.google.com", "adnxs.com", "adsystem.com", "adform.net",
        "taboola.com", "outbrain.com", "popads.net", "popcash.net",
        "exoclick.com", "trafficjunky.net", "adcolony.com"
    )
    @Volatile private var remoteHosts: Set<String> = emptySet()

    fun refreshRemoteList(context: Context, url: String) {
        if (url.isBlank()) return
        Thread {
            var connection: HttpURLConnection? = null
            try {
                connection = (URL(url).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 8000
                    readTimeout = 8000
                    requestMethod = "GET"
                }
                if (connection.responseCode in 200..299) {
                    val parsed = connection.inputStream.bufferedReader().useLines { lines ->
                        lines.map { it.trim() }
                            .filter { it.isNotEmpty() && !it.startsWith("#") }
                            .mapNotNull { line ->
                                val host = line.substringAfter("||", line)
                                    .substringBefore("^").substringBefore("\\$")
                                    .substringBefore("/").trim().lowercase(Locale.US)
                                host.takeIf { it.contains('.') && !it.contains(' ') && !it.startsWith("!") }
                            }.toSet()
                    }
                    remoteHosts = parsed
                }
            } catch (_: Exception) {
            } finally {
                connection?.disconnect()
            }
        }.start()
    }

    fun shouldBlock(rawUrl: String): Boolean {
        val host = try { URL(rawUrl).host.lowercase(Locale.US) } catch (_: Exception) { return false }
        if (host.isBlank()) return false
        val all = builtInHosts + remoteHosts
        return all.any { host == it || host.endsWith(".$it") }
    }

    fun blockedResponse(): WebResourceResponse =
        WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
}
