package com.example.oneapp

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private var webView: WebView? = null
    private var currentPage = "home"
    private val importConfigRequest = 4102
    private val permissionRequest = 4103
    private val backupWorkName = "oneapp_periodic_gallery_backup"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CookieManager.getInstance().setAcceptCookie(true)
        val cfg = AppConfig.load(this)
        AdBlocker.refreshRemoteList(this, cfg.adblockFilterUrl)
        if (cfg.autoBackup) schedulePeriodicBackup()
        showHome()
        requestMediaPermissionsIfNeeded()
    }

    private fun base(title: String) {
        webView?.destroy()
        webView = null
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(10))
            setBackgroundColor(0xFF101419.toInt())
        }
        val header = TextView(this).apply {
            text = title
            textSize = 23f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, dp(4), 0, dp(14))
        }
        root.addView(header)
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun button(text: String, action: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            textSize = 15f
            setOnClickListener { action() }
            root.addView(this, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(8) })
        }

    private fun note(text: String) {
        root.addView(TextView(this).apply {
            this.text = text
            textSize = 14f
            setTextColor(0xFFD2D8DE.toInt())
            setPadding(0, dp(6), 0, dp(6))
        })
    }

    private fun edit(hint: String, value: String = ""): EditText {
        val e = EditText(this).apply {
            this.hint = hint
            setText(value)
            setSingleLine(true)
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF9AA5AF.toInt())
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setBackgroundColor(0xFF252D35.toInt())
        }
        root.addView(e, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(5) })
        return e
    }

    private fun showHome() {
        currentPage = "home"
        base("OneApp • এক অ্যাপে সব")
        note("একই অ্যাপে YouTube, সাধারণ বিজ্ঞাপন/ট্র্যাকার ব্লক করার চেষ্টা এবং Telegram গ্যালারি ব্যাকআপ।")
        button("▶ YouTube খুলুন") { openWeb(AppConfig.load(this).youtubeUrl) }
        button("🌐 URL লিখে খুলুন") { showUrlPage() }
        button("☁ গ্যালারি ব্যাকআপ এখনই শুরু করুন") { startManualBackup() }
        button("⚙ সেটিংস / XX.json") { showSettings() }
        note("ব্যাকআপের জন্য ছবি ও ভিডিওর অনুমতি এবং Telegram bot token + channel/chat ID লাগবে।")
        note("সতর্কতা: WebView-এ YouTube-এর সব ভিডিও বিজ্ঞাপন ব্লক করা নিশ্চিত নয়।")
        val prefs = getSharedPreferences("backup_state", MODE_PRIVATE)
        val count = prefs.getStringSet("sent_media_ids", emptySet())?.size ?: 0
        val last = prefs.getLong("last_run", 0L)
        note("এই ডিভাইসে ব্যাকআপ হিসেবে চিহ্নিত মিডিয়া: $count\nশেষ ব্যাকআপ চেষ্টা: " +
            if (last == 0L) "এখনও নয়" else java.text.DateFormat.getDateTimeInstance().format(java.util.Date(last)))
    }

    private fun showUrlPage() {
        currentPage = "url"
        base("ওয়েবসাইট খুলুন")
        val urlInput = edit("https://example.com", AppConfig.load(this).startUrl)
        button("ওপেন") { openWeb(AppConfig.safeWebUrl(urlInput.text.toString())) }
        button("YouTube") { openWeb(AppConfig.load(this).youtubeUrl) }
        button("হোমে ফিরুন") { showHome() }
    }

    private fun openWeb(rawUrl: String) {
        val url = AppConfig.safeWebUrl(rawUrl)
        currentPage = "web"
        base("ওয়েব • $url")
        button("← হোম") { showHome() }
        button("↻ রিফ্রেশ") { webView?.reload() }
        val wv = WebView(this)
        webView = wv
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.settings.mediaPlaybackRequiresUserGesture = true
        wv.settings.loadsImagesAutomatically = true
        wv.webChromeClient = WebChromeClient()
        wv.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val scheme = request.url.scheme?.lowercase()
                return scheme != "http" && scheme != "https"
            }

            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): android.webkit.WebResourceResponse? {
                val cfg = AppConfig.load(this@MainActivity)
                if (cfg.adblockEnabled && AdBlocker.shouldBlock(request.url.toString())) {
                    return AdBlocker.blockedResponse()
                }
                return super.shouldInterceptRequest(view, request)
            }
        }
        root.addView(wv, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(560)
        ).apply { topMargin = dp(8) })
        wv.loadUrl(url)
    }

    private fun showSettings() {
        currentPage = "settings"
        base("সেটিংস")
        val c = AppConfig.load(this)
        note("Telegram Bot Token")
        val token = edit("123456:ABC...", c.botToken)
        note("Telegram Channel ID / Chat ID (যেমন -100...)")
        val chat = edit("-1001234567890", c.channelId)
        note("YouTube URL")
        val youtube = edit("https://m.youtube.com/", c.youtubeUrl)
        note("ডিফল্ট URL")
        val start = edit("https://example.com/", c.startUrl)
        note("Ad-block filter URL (ঐচ্ছিক; plain domain list/সহজ filter list)")
        val filter = edit("https://example.com/filters.txt", c.adblockFilterUrl)
        val adblock = CheckBox(this).apply {
            text = "অ্যাড/ট্র্যাকার ব্লক চালু"
            setTextColor(0xFFFFFFFF.toInt())
            isChecked = c.adblockEnabled
            root.addView(this)
        }
        val auto = CheckBox(this).apply {
            text = "প্রতি ১৫ মিনিট বা তার বেশি ব্যবধানে অটো ব্যাকআপ চালু"
            setTextColor(0xFFFFFFFF.toInt())
            isChecked = c.autoBackup
            root.addView(this)
        }
        button("সেটিংস সেভ করুন") {
            val cfg = AppConfig(
                botToken = token.text.toString().trim(),
                channelId = chat.text.toString().trim(),
                youtubeUrl = AppConfig.safeWebUrl(youtube.text.toString()),
                startUrl = AppConfig.safeWebUrl(start.text.toString()),
                adblockFilterUrl = AppConfig.safeWebUrlAllowBlank(filter.text.toString()),
                adblockEnabled = adblock.isChecked,
                autoBackup = auto.isChecked
            )
            AppConfig.save(this, cfg)
            AdBlocker.refreshRemoteList(this, cfg.adblockFilterUrl)
            if (cfg.autoBackup) schedulePeriodicBackup() else WorkManager.getInstance(this).cancelUniqueWork(backupWorkName)
            Toast.makeText(this, "সেটিংস সেভ হয়েছে", Toast.LENGTH_SHORT).show()
            showHome()
        }
        button("MT Manager দিয়ে সম্পাদিত XX.json ইমপোর্ট") {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "application/json"
            }
            startActivityForResult(intent, importConfigRequest)
        }
        button("বর্তমান সেটিংস XX.json হিসেবে এক্সপোর্ট") { exportConfig() }
        button("হোমে ফিরুন") { showHome() }
        note("Token কনফিগে রাখলে তা বের করা সম্ভব। ব্যক্তিগত বট ব্যবহার করুন; কখনও অন্যের কাছে token দেবেন না।")
    }

    private fun exportConfig() {
        val cfg = AppConfig.load(this)
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/json"
            putExtra(Intent.EXTRA_TITLE, "XX.json")
        }
        pendingExport = cfg.toJson().toString(2)
        startActivityForResult(intent, 4104)
    }

    private var pendingExport: String = ""

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        val uri = data.data!!
        when (requestCode) {
            importConfigRequest -> {
                try {
                    contentResolver.openInputStream(uri)?.bufferedReader()?.use {
                        val cfg = AppConfig.parse(it.readText())
                        AppConfig.save(this, cfg)
                        AdBlocker.refreshRemoteList(this, cfg.adblockFilterUrl)
                        if (cfg.autoBackup) schedulePeriodicBackup()
                        else WorkManager.getInstance(this).cancelUniqueWork(backupWorkName)
                        Toast.makeText(this, "XX.json ইমপোর্ট হয়েছে", Toast.LENGTH_LONG).show()
                        showHome()
                    }
                } catch (e: Exception) {
                    Toast.makeText(this, "JSON ভুল: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
            4104 -> {
                try {
                    contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(pendingExport) }
                    Toast.makeText(this, "XX.json সেভ হয়েছে", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "ফাইল সেভ হয়নি", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun startManualBackup() {
        if (!hasMediaPermissions()) {
            requestMediaPermissionsIfNeeded()
            Toast.makeText(this, "অনুমতি দিন, তারপর আবার ব্যাকআপ চাপুন", Toast.LENGTH_LONG).show()
            return
        }
        val request = OneTimeWorkRequestBuilder<TelegramBackupWorker>()
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(this).enqueue(request)
        Toast.makeText(this, "ব্যাকআপ কিউতে যোগ হয়েছে; ইন্টারনেট থাকলে চলবে", Toast.LENGTH_LONG).show()
    }

    private fun schedulePeriodicBackup() {
        if (!hasMediaPermissions()) return
        val request = PeriodicWorkRequestBuilder<TelegramBackupWorker>(15, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            backupWorkName, ExistingPeriodicWorkPolicy.UPDATE, request
        )
    }

    private fun hasMediaPermissions(): Boolean {
        val permissions = if (Build.VERSION.SDK_INT >= 33) {
            arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
        } else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        return permissions.all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }
    }

    private fun requestMediaPermissionsIfNeeded() {
        if (hasMediaPermissions()) return
        val permissions = if (Build.VERSION.SDK_INT >= 33) {
            arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
        } else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        ActivityCompat.requestPermissions(this, permissions, permissionRequest)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == permissionRequest && grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
            if (AppConfig.load(this).autoBackup) schedulePeriodicBackup()
            Toast.makeText(this, "গ্যালারি অনুমতি দেওয়া হয়েছে", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onBackPressed() {
        if (webView?.canGoBack() == true) webView?.goBack() else showHome()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
