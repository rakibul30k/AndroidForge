package com.homeintercom;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.media.AudioManager;
import android.os.IBinder;
import android.os.Build;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DatabaseReference.CompletionListener;

import org.webrtc.AudioSource;
import org.webrtc.AudioTrack;
import org.webrtc.Camera2Enumerator;
import org.webrtc.MediaConstraints;
import org.webrtc.PeerConnection;
import org.webrtc.PeerConnectionFactory;
import org.webrtc.RtpReceiver;
import org.webrtc.RtpTransceiver;
import org.webrtc.SessionDescription;
import org.webrtc.IceCandidate;
import org.webrtc.SdpObserver;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class IntercomService extends Service {
    private static final String CHANNEL_ID = "home_intercom";
    private PeerConnectionFactory factory;
    private PeerConnection peer;
    private AudioSource audioSource;
    private AudioTrack localAudio;
    private DatabaseReference roomRef;
    private String room;
    private String peerId;
    private ValueEventListener signalListener;

    @Override public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(7, notification());

        PeerConnectionFactory.initialize(
                PeerConnectionFactory.InitializationOptions.builder(this)
                        .setEnableInternalTracer(false).createInitializationOptions());

        factory = PeerConnectionFactory.builder().createPeerConnectionFactory();

        AudioManager am = (AudioManager)getSystemService(AUDIO_SERVICE);
        am.setMode(AudioManager.MODE_IN_COMMUNICATION);
        am.setSpeakerphoneOn(true);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.hasExtra("room")) {
            String newRoom = intent.getStringExtra("room");
            if (newRoom != null && !newRoom.trim().isEmpty() &&
                    (room == null || !room.equals(newRoom.trim()))) {
                room = newRoom.trim();
                connectRoom();
            }
        }
        return START_STICKY;
    }

    private void connectRoom() {
        if (roomRef != null) {
            try { roomRef.child("peers").child(peerId).removeValue(); } catch (Exception ignored) {}
        }

        peerId = UUID.randomUUID().toString().replace("-", "").substring(0, 12);
        roomRef = FirebaseDatabase.getInstance().getReference()
                .child("homeIntercomV2").child("rooms").child(room);

        roomRef.child("peers").child(peerId).setValue(true);

        setupPeer();
        listenForSignals();

        roomRef.child("peers").addValueEventListener(new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snapshot) {
                List<String> ids = new ArrayList<>();
                for (DataSnapshot s : snapshot.getChildren()) ids.add(s.getKey());
                Collections.sort(ids);
                if (ids.size() >= 2 && peerId.equals(ids.get(0))) {
                    makeOffer();
                }
            }
            @Override public void onCancelled(DatabaseError error) {}
        });
    }

    private void setupPeer() {
        PeerConnection.RTCConfiguration config =
                new PeerConnection.RTCConfiguration(
                        Collections.singletonList(
                                PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer()));
        config.sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN;

        peer = factory.createPeerConnection(config, new PeerConnection.Observer() {
            @Override public void onSignalingChange(PeerConnection.SignalingState s) {}
            @Override public void onIceConnectionChange(PeerConnection.IceConnectionState s) {
                if (s == PeerConnection.IceConnectionState.DISCONNECTED ||
                    s == PeerConnection.IceConnectionState.FAILED) {
                    try { peer.restartIce(); } catch (Exception ignored) {}
                }
            }
            @Override public void onIceConnectionReceivingChange(boolean b) {}
            @Override public void onIceGatheringChange(PeerConnection.IceGatheringState s) {}
            @Override public void onIceCandidate(IceCandidate c) {
                Map<String,Object> m = new HashMap<>();
                m.put("sdpMid", c.sdpMid);
                m.put("sdpMLineIndex", c.sdpMLineIndex);
                m.put("candidate", c.sdp);
                roomRef.child("ice").child(peerId).push().setValue(m);
            }
            @Override public void onIceCandidatesRemoved(IceCandidate[] c) {}
            @Override public void onAddStream(org.webrtc.MediaStream s) {}
            @Override public void onRemoveStream(org.webrtc.MediaStream s) {}
            @Override public void onDataChannel(org.webrtc.DataChannel d) {}
            @Override public void onRenegotiationNeeded() {}
            @Override public void onAddTrack(RtpReceiver receiver, org.webrtc.MediaStream[] streams) {
                if (receiver.track() instanceof AudioTrack) {
                    ((AudioTrack) receiver.track()).setEnabled(true);
                }
            }
        });

        MediaConstraints constraints = new MediaConstraints();
        audioSource = factory.createAudioSource(constraints);
        localAudio = factory.createAudioTrack("local_audio", audioSource);
        localAudio.setEnabled(true);
        peer.addTrack(localAudio);
    }

    private void listenForSignals() {
        signalListener = roomRef.addValueEventListener(new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snapshot) {
                DataSnapshot offer = snapshot.child("offer");
                DataSnapshot answer = snapshot.child("answer");

                if (offer.exists() && !peerId.equals(snapshot.child("offerOwner").getValue(String.class))
                        && peer.getRemoteDescription() == null) {
                    String sdp = offer.child("sdp").getValue(String.class);
                    if (sdp != null) {
                        peer.setRemoteDescription(new SimpleSdpObserver() {
                            @Override public void onSetSuccess() {
                                createAnswer();
                            }
                        }, new SessionDescription(SessionDescription.Type.OFFER, sdp));
                    }
                }

                if (answer.exists() && peer.getRemoteDescription() == null) {
                    String sdp = answer.child("sdp").getValue(String.class);
                    if (sdp != null) {
                        peer.setRemoteDescription(new SimpleSdpObserver(){}, 
                                new SessionDescription(SessionDescription.Type.ANSWER, sdp));
                    }
                }
            }
            @Override public void onCancelled(DatabaseError error) {}
        });

        roomRef.child("ice").addChildEventListener(new ChildEventListener() {
            @Override public void onChildAdded(DataSnapshot peerSnap, String prev) {
                if (peerSnap.getKey().equals(peerId)) return;
                for (DataSnapshot c : peerSnap.getChildren()) {
                    String mid = c.child("sdpMid").getValue(String.class);
                    Integer idx = c.child("sdpMLineIndex").getValue(Integer.class);
                    String cand = c.child("candidate").getValue(String.class);
                    if (mid != null && idx != null && cand != null) {
                        try { peer.addIceCandidate(new IceCandidate(mid, idx, cand)); } catch (Exception ignored) {}
                    }
                }
            }
            @Override public void onChildChanged(DataSnapshot s, String p) {}
            @Override public void onChildRemoved(DataSnapshot s) {}
            @Override public void onChildMoved(DataSnapshot s, String p) {}
            @Override public void onCancelled(DatabaseError e) {}
        });
    }

    private void makeOffer() {
        if (peer == null || peer.getLocalDescription() != null) return;
        peer.createOffer(new SimpleSdpObserver() {
            @Override public void onCreateSuccess(SessionDescription sdp) {
                peer.setLocalDescription(new SimpleSdpObserver() {
                    @Override public void onSetSuccess() {
                        Map<String,Object> m = new HashMap<>();
                        m.put("type", "offer");
                        m.put("sdp", sdp.description);
                        roomRef.child("offerOwner").setValue(peerId);
                        roomRef.child("offer").setValue(m);
                    }
                }, sdp);
            }
        }, new MediaConstraints());
    }

    private void createAnswer() {
        peer.createAnswer(new SimpleSdpObserver() {
            @Override public void onCreateSuccess(SessionDescription sdp) {
                peer.setLocalDescription(new SimpleSdpObserver() {
                    @Override public void onSetSuccess() {
                        Map<String,Object> m = new HashMap<>();
                        m.put("type", "answer");
                        m.put("sdp", sdp.description);
                        roomRef.child("answer").setValue(m);
                    }
                }, sdp);
            }
        }, new MediaConstraints());
    }

    private Notification notification() {
        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle(getString(com.homeintercom.R.string.notification_title))
                .setContentText(getString(com.homeintercom.R.string.notification_text))
                .setOngoing(true)
                .setCategory(NotificationCompat.CATEGORY_SERVICE)
                .build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID, getString(R.string.notification_channel_name),
                    NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE))
                    .createNotificationChannel(ch);
        }
    }

    @Override public void onDestroy() {
        try {
            if (roomRef != null && peerId != null)
                roomRef.child("peers").child(peerId).removeValue();
        } catch (Exception ignored) {}

        if (peer != null) peer.close();
        if (localAudio != null) localAudio.dispose();
        if (audioSource != null) audioSource.dispose();
        if (factory != null) factory.dispose();

        AudioManager am = (AudioManager)getSystemService(AUDIO_SERVICE);
        am.setMode(AudioManager.MODE_NORMAL);
        am.setSpeakerphoneOn(false);
        super.onDestroy();
    }

    @Nullable @Override public IBinder onBind(Intent intent) { return null; }

    static class SimpleSdpObserver implements SdpObserver {
        public void onCreateSuccess(SessionDescription s) {}
        public void onSetSuccess() {}
        public void onCreateFailure(String s) {}
        public void onSetFailure(String s) {}
    }
}
