package com.homeintercom;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.activity.ComponentActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends ComponentActivity {
    private static final int MIC_REQUEST = 1001;
    private static final int NOTIF_REQUEST = 1002;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText room = findViewById(R.id.roomCode);
        Button connect = findViewById(R.id.connectButton);
        Button disconnect = findViewById(R.id.disconnectButton);
        TextView status = findViewById(R.id.statusText);

        SharedPreferences sp = getSharedPreferences("home_intercom", MODE_PRIVATE);
        room.setText(sp.getString("room", ""));

        connect.setOnClickListener(v -> {
            String code = room.getText().toString().trim();
            if (code.isEmpty()) {
                status.setText("একটি Room Code দিন");
                return;
            }
            sp.edit().putString("room", code).apply();

            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.RECORD_AUDIO}, MIC_REQUEST);
                return;
            }
            startIntercom(code);
        });

        disconnect.setOnClickListener(v -> {
            stopService(new Intent(this, IntercomService.class));
            status.setText("Disconnected");
        });
    }

    private void startIntercom(String code) {
        if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIF_REQUEST);
        }

        Intent i = new Intent(this, IntercomService.class);
        i.putExtra("room", code);
        ContextCompat.startForegroundService(this, i);
        ((TextView)findViewById(R.id.statusText)).setText(
                "Connected — screen বন্ধ করলেও Intercom চলবে");
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == MIC_REQUEST && results.length > 0 &&
                results[0] == PackageManager.PERMISSION_GRANTED) {
            EditText room = findViewById(R.id.roomCode);
            startIntercom(room.getText().toString().trim());
        }
    }
}
