package com.homeintercom;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.media.AudioManager;
import android.os.Build;
import android.os.IBinder;
import android.content.pm.ServiceInfo;

import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.webrtc.AudioSource;
import org.webrtc.AudioTrack;
import org.webrtc.JavaAudioDeviceModule;
import org.webrtc.MediaConstraints;
import org.webrtc.PeerConnection;
import org.webrtc.PeerConnectionFactory;
import org.webrtc.RtpReceiver;
import org.webrtc.SdpObserver;
import org.webrtc.SessionDescription;
import org.webrtc.IceCandidate;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class IntercomService extends Service {
    private static final String CHANNEL = "riyan_intercom";
    private static final String DB_URL = "https://fast-pay-5efbb-default-rtdb.firebaseio.com";
    private static final String APP_ID = "1:432258030935:android:b81a7098967a876a603212";
    private static final String API_KEY = "AIzaSyCuSWA2-HGDRlisg0ng-IzkVyD4ooZASSI";
    private static final String PROJECT = "fast-pay-5efbb";

    private PeerConnectionFactory factory;
    private PeerConnection peer;
    private AudioSource source;
    private AudioTrack localTrack;
    private DatabaseReference roomRef;
    private DatabaseReference pairRef;
    private String roomCode;
    private String myId;
    private String remoteId;
    private boolean initiator;
    private boolean connectedSignaling;
    private ValueEventListener membersListener;
    private ValueEventListener signalListener;
    private ChildEventListener remoteIceListener;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(101, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
        } else {
            startForeground(101, notification());
        }
        initFirebase();
        PeerConnectionFactory.initialize(PeerConnectionFactory.InitializationOptions.builder(this).createInitializationOptions());
        JavaAudioDeviceModule adm = JavaAudioDeviceModule.builder(this)
                .setUseHardwareAcousticEchoCanceler(true)
                .setUseHardwareNoiseSuppressor(true)
                .createAudioDeviceModule();
        factory = PeerConnectionFactory.builder().setAudioDeviceModule(adm).createPeerConnectionFactory();
        adm.release();
        AudioManager audio = (AudioManager) getSystemService(AUDIO_SERVICE);
        audio.setMode(AudioManager.MODE_IN_COMMUNICATION);
        audio.setSpeakerphoneOn(true);
    }

    private void initFirebase() {
        if (FirebaseApp.getApps(this).isEmpty()) {
            FirebaseOptions opts = FirebaseOptions.builder().setApplicationId(APP_ID).setApiKey(API_KEY).setProjectId(PROJECT).setDatabaseUrl(DB_URL).build();
            FirebaseApp.initializeApp(this, opts);
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String newRoom = intent == null ? null : intent.getStringExtra("room");
        if (newRoom != null && !newRoom.trim().isEmpty() && !newRoom.trim().equals(roomCode)) {
            disconnectInternal();
            roomCode = newRoom.trim();
            joinRoom();
        }
        return START_STICKY;
    }

    private void joinRoom() {
        myId = UUID.randomUUID().toString().replace("-", "").substring(0, 12);
        roomRef = FirebaseDatabase.getInstance().getReference("homeIntercomV2/rooms").child(roomCode);
        DatabaseReference me = roomRef.child("members").child(myId);
        me.setValue(System.currentTimeMillis());
        me.onDisconnect().removeValue();

        membersListener = roomRef.child("members").addValueEventListener(new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot s) {
                List<String> ids = new ArrayList<>();
                for (DataSnapshot c : s.getChildren()) if (c.getKey() != null) ids.add(c.getKey());
                Collections.sort(ids);
                if (ids.size() == 2) {
                    String a = ids.get(0), b = ids.get(1);
                    remoteId = myId.equals(a) ? b : a;
                    initiator = myId.equals(a);
                    String pairId = a + "_" + b;
                    if (!connectedSignaling || pairRef == null || !pairId.equals(pairRef.getKey())) {
                        setupPair(pairId);
                    }
                }
            }
            @Override public void onCancelled(DatabaseError e) {}
        });
    }

    private void setupPair(String pairId) {
        connectedSignaling = true;
        pairRef = roomRef.child("pairs").child(pairId);
        setupPeer();
        listenForSignals();
        if (initiator) makeOffer();
    }

    private void setupPeer() {
        PeerConnection.RTCConfiguration cfg = new PeerConnection.RTCConfiguration(Collections.singletonList(
                PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer()));
        cfg.sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN;
        peer = factory.createPeerConnection(cfg, new PeerConnection.Observer() {
            @Override public void onSignalingChange(PeerConnection.SignalingState s) {}
            @Override public void onIceConnectionChange(PeerConnection.IceConnectionState s) {
                if (s == PeerConnection.IceConnectionState.FAILED) { try { peer.restartIce(); } catch (Exception ignored) {} }
            }
            @Override public void onIceConnectionReceivingChange(boolean b) {}
            @Override public void onIceGatheringChange(PeerConnection.IceGatheringState s) {}
            @Override public void onIceCandidate(IceCandidate c) {
                if (pairRef == null) return;
                Map<String,Object> m = new HashMap<>();
                m.put("sdpMid", c.sdpMid); m.put("sdpMLineIndex", c.sdpMLineIndex); m.put("candidate", c.sdp);
                pairRef.child("ice").child(myId).push().setValue(m);
            }
            @Override public void onIceCandidatesRemoved(IceCandidate[] c) {}
            @Override public void onAddStream(org.webrtc.MediaStream s) {}
            @Override public void onRemoveStream(org.webrtc.MediaStream s) {}
            @Override public void onDataChannel(org.webrtc.DataChannel d) {}
            @Override public void onRenegotiationNeeded() {}
            @Override public void onAddTrack(RtpReceiver receiver, org.webrtc.MediaStream[] streams) {
                if (receiver.track() instanceof AudioTrack) ((AudioTrack) receiver.track()).setEnabled(true);
            }
        });
        source = factory.createAudioSource(new MediaConstraints());
        localTrack = factory.createAudioTrack("riyan_local_audio", source);
        localTrack.setEnabled(true);
        peer.addTrack(localTrack);
    }

    private void listenForSignals() {
        signalListener = pairRef.addValueEventListener(new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot s) {
                if (peer == null) return;
                DataSnapshot offer = s.child("offer");
                DataSnapshot answer = s.child("answer");
                String owner = s.child("offerOwner").getValue(String.class);
                if (offer.exists() && owner != null && !owner.equals(myId) && peer.getRemoteDescription() == null) {
                    String text = offer.child("sdp").getValue(String.class);
                    if (text != null) peer.setRemoteDescription(new SdpObserverBase() {
                        @Override public void onSetSuccess() { createAnswer(); }
                    }, new SessionDescription(SessionDescription.Type.OFFER, text));
                }
                if (answer.exists() && initiator && peer.getRemoteDescription() == null) {
                    String text = answer.child("sdp").getValue(String.class);
                    if (text != null) peer.setRemoteDescription(new SdpObserverBase(){}, new SessionDescription(SessionDescription.Type.ANSWER, text));
                }
            }
            @Override public void onCancelled(DatabaseError e) {}
        });
        remoteIceListener = pairRef.child("ice").child(remoteId).addChildEventListener(new ChildEventListener() {
            @Override public void onChildAdded(DataSnapshot c, String prev) {
                String mid = c.child("sdpMid").getValue(String.class);
                Integer idx = c.child("sdpMLineIndex").getValue(Integer.class);
                String candidate = c.child("candidate").getValue(String.class);
                if (mid != null && idx != null && candidate != null && peer != null) {
                    peer.addIceCandidate(new IceCandidate(mid, idx, candidate));
                }
            }
            @Override public void onChildChanged(DataSnapshot s, String p) {}
            @Override public void onChildRemoved(DataSnapshot s) {}
            @Override public void onChildMoved(DataSnapshot s, String p) {}
            @Override public void onCancelled(DatabaseError e) {}
        });
    }

    private void makeOffer() {
        if (peer == null) return;
        peer.createOffer(new SdpObserverBase() {
            @Override public void onCreateSuccess(SessionDescription s) {
                peer.setLocalDescription(new SdpObserverBase() {
                    @Override public void onSetSuccess() {
                        Map<String,Object> m = new HashMap<>(); m.put("sdp", s.description);
                        pairRef.child("offerOwner").setValue(myId); pairRef.child("offer").setValue(m);
                    }
                }, s);
            }
        }, new MediaConstraints());
    }

    private void createAnswer() {
        peer.createAnswer(new SdpObserverBase() {
            @Override public void onCreateSuccess(SessionDescription s) {
                peer.setLocalDescription(new SdpObserverBase() {
                    @Override public void onSetSuccess() { pairRef.child("answer").child("sdp").setValue(s.description); }
                }, s);
            }
        }, new MediaConstraints());
    }

    private Notification notification() {
        return new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("RIYAN HOME INTERCOM")
                .setContentText("Two-way microphone intercom is active")
                .setOngoing(true).build();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "Home Intercom", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }

    private void disconnectInternal() {
        try { if (roomRef != null && myId != null) roomRef.child("members").child(myId).removeValue(); } catch (Exception ignored) {}
        if (membersListener != null && roomRef != null) roomRef.child("members").removeEventListener(membersListener);
        if (signalListener != null && pairRef != null) pairRef.removeEventListener(signalListener);
        if (remoteIceListener != null && pairRef != null && remoteId != null) pairRef.child("ice").child(remoteId).removeEventListener(remoteIceListener);
        connectedSignaling = false; remoteId = null; pairRef = null;
        if (peer != null) { peer.close(); peer.dispose(); peer = null; }
        if (localTrack != null) { localTrack.dispose(); localTrack = null; }
        if (source != null) { source.dispose(); source = null; }
    }

    @Override public void onDestroy() {
        disconnectInternal();
        if (factory != null) { factory.dispose(); factory = null; }
        AudioManager audio = (AudioManager)getSystemService(AUDIO_SERVICE);
        audio.setMode(AudioManager.MODE_NORMAL); audio.setSpeakerphoneOn(false);
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    static class SdpObserverBase implements SdpObserver {
        @Override public void onCreateSuccess(SessionDescription s) {}
        @Override public void onSetSuccess() {}
        @Override public void onCreateFailure(String s) {}
        @Override public void onSetFailure(String s) {}
    }
}
