package com.homeintercom;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int MIC_REQUEST = 10;
    private EditText room;
    private TextView status;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_main);
        room = findViewById(R.id.roomCode);
        status = findViewById(R.id.statusText);
        Button connect = findViewById(R.id.connectButton);
        Button disconnect = findViewById(R.id.disconnectButton);
        SharedPreferences prefs = getSharedPreferences("intercom", MODE_PRIVATE);
        room.setText(prefs.getString("room", ""));

        connect.setOnClickListener(v -> connect());
        disconnect.setOnClickListener(v -> {
            stopService(new Intent(this, IntercomService.class));
            status.setText("Disconnected");
        });
    }

    private void connect() {
        String code = room.getText().toString().trim();
        if (code.isEmpty()) { status.setText("Room Code দিন"); return; }
        getSharedPreferences("intercom", MODE_PRIVATE).edit().putString("room", code).apply();
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC_REQUEST);
            return;
        }
        startServiceNow(code);
    }

    private void startServiceNow(String code) {
        Intent i = new Intent(this, IntercomService.class).putExtra("room", code);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        status.setText("Connecting… দুই ফোন একই Room Code ব্যবহার করুন");
    }

    @Override public void onRequestPermissionsResult(int request, String[] p, int[] r) {
        super.onRequestPermissionsResult(request, p, r);
        if (request == MIC_REQUEST && r.length > 0 && r[0] == PackageManager.PERMISSION_GRANTED) {
            startServiceNow(room.getText().toString().trim());
        } else if (request == MIC_REQUEST) {
            status.setText("Microphone permission ছাড়া intercom চালানো যাবে না");
        }
    }
}
