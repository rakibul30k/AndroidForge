RIYAN HOME INTERCOM - fresh Android project

Build target: Android SDK 34 / AGP 8.4.2 / JDK 17.
Uses Firebase Realtime Database for signaling and WebRTC for live two-way audio.

Important: Firebase Realtime Database rules are expected at homeIntercomV2.
