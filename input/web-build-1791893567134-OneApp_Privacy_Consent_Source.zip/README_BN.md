# OneApp — YouTube + Gallery Backup + Privacy Consent

এটি Kotlin/Android Studio সোর্স প্রজেক্ট, তৈরি APK নয়। বাস্তব ফোনে ইনস্টল করার আগে বিল্ড ও পরীক্ষা আবশ্যক।

## কী আছে
- প্রথমবার চালু হলে বাংলা গোপনীয়তা সতর্কবার্তা দেখায়; সম্মতি না দিলে গ্যালারি permission prompt আসে না।
- YouTube / custom URL WebView-তে খোলে।
- সীমিত built-in ad/tracker host blocking; YouTube-এর সব ভিডিও বিজ্ঞাপন বন্ধের নিশ্চয়তা নেই।
- Telegram Bot API-তে MediaStore থেকে ছবি/ভিডিও ব্যাকআপের starter implementation।
- Auto backup ডিফল্টে OFF; Settings-এ user নিজে চালু করতে পারে।
- `XX.json` import/export, তাই MT Manager-এ ফাইল edit করে app-এ import করা যায়।
- Settings-এ backup destination স্পষ্টভাবে দেখায় এবং manual/automatic backup control আছে।

## সীমাবদ্ধতা / সততা
- এই প্রজেক্টটি এখানে Android SDK দিয়ে compile বা real device-এ test করা হয়নি। তাই compile/runtime error হতে পারে।
- Background work Android battery policy-তে দেরি হতে পারে; periodic work best-effort।
- YouTube WebView playback/login সীমাবদ্ধ হতে পারে; সব ads block হবে না।
- Telegram bot token অ্যাপ বা JSON-এ রাখলে বের করা সম্ভব। শুধু নিজের bot ব্যবহার করুন।
- নতুন media-র auto-detection WorkManager-এর মাধ্যমে periodic scan; instant নয়।
- Partial media permission দিলে সব media দেখা নাও যেতে পারে।
- 49 MB-এর বেশি ফাইল skip করা হয়।
- অন্যের ফোনে ব্যবহার করলে সেই ব্যক্তির স্পষ্ট সম্মতি নিতে হবে।

## Build
1. Android Studio-তে project folder খুলুন.
2. Gradle sync করুন.
3. Build > Build APK(s).
4. Install করে permission, URL, Telegram token/channel ID এবং backup flow পরীক্ষা করুন.

## XX.json example
```json
{
  "bot_token": "YOUR_TELEGRAM_BOT_TOKEN",
  "channel_id": "-1001234567890",
  "youtube_url": "https://m.youtube.com/",
  "start_url": "https://m.youtube.com/",
  "adblock_filter_url": "",
  "adblock_enabled": true,
  "auto_backup": false
}
```
