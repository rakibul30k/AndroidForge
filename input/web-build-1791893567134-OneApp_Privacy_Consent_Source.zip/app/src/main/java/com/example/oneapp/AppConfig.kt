package com.example.oneapp

import android.content.Context
import org.json.JSONObject

data class AppConfig(
    val botToken: String = "",
    val channelId: String = "",
    val youtubeUrl: String = "https://m.youtube.com/",
    val startUrl: String = "https://m.youtube.com/",
    val adblockFilterUrl: String = "",
    val adblockEnabled: Boolean = true,
    val autoBackup: Boolean = false
) {
    fun toJson() = JSONObject().apply {
        put("bot_token", botToken)
        put("channel_id", channelId)
        put("youtube_url", youtubeUrl)
        put("start_url", startUrl)
        put("adblock_filter_url", adblockFilterUrl)
        put("adblock_enabled", adblockEnabled)
        put("auto_backup", autoBackup)
    }

    companion object {
        private const val PREFS = "oneapp_config"
        private const val KEY = "config_json"

        fun load(context: Context): AppConfig {
            val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val raw = p.getString(KEY, null) ?: runCatching {
                context.assets.open("XX.json").bufferedReader().use { it.readText() }
            }.getOrDefault("{}")
            return parse(raw)
        }
        fun save(context: Context, c: AppConfig) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString(KEY, c.toJson().toString()).apply()
        }
        fun parse(raw: String): AppConfig {
            val j = JSONObject(raw)
            val yt = safeUrl(j.optString("youtube_url", "https://m.youtube.com/"))
            return AppConfig(
                j.optString("bot_token", ""),
                j.optString("channel_id", ""),
                yt,
                safeUrl(j.optString("start_url", yt)),
                safeUrlOrBlank(j.optString("adblock_filter_url", "")),
                j.optBoolean("adblock_enabled", true),
                j.optBoolean("auto_backup", false)
            )
        }
        fun safeUrl(s: String): String {
            val v = s.trim()
            return if (v.startsWith("https://", true) || v.startsWith("http://", true)) v
                else "https://m.youtube.com/"
        }
        fun safeUrlOrBlank(s: String): String {
            val v = s.trim()
            return if (v.isBlank() || v.startsWith("https://", true) || v.startsWith("http://", true)) v else ""
        }
    }
}
