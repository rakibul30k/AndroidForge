package com.example.oneapp

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.*
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.work.*
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private var web: WebView? = null
    private val importRequest = 5001
    private val exportRequest = 5002
    private val permissionRequest = 5003
    private var exportJson = ""
    private val periodicName = "oneapp_auto_gallery_backup"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val c = AppConfig.load(this)
        AdBlocker.refresh(c.adblockFilterUrl)
        if (getSharedPreferences("consent", MODE_PRIVATE).getBoolean("notice_seen", false)) {
            showHome()
            if (hasMediaPermissions() && c.autoBackup) scheduleBackup()
        } else showPrivacyNotice()
    }

    private fun setup(title: String) {
        web?.destroy(); web = null
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            setBackgroundColor(0xFF11161C.toInt())
        }
        root.addView(TextView(this).apply {
            text = title; textSize = 22f; setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 0, 0, dp(10))
        })
        val scroll = ScrollView(this); scroll.addView(root); setContentView(scroll)
    }
    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun note(s: String) { root.addView(TextView(this).apply {
        text = s; textSize = 14f; setTextColor(0xFFE0E5EA.toInt()); setPadding(0, dp(6), 0, dp(6))
    }) }
    private fun button(s: String, action: () -> Unit) {
        root.addView(Button(this).apply { text = s; setOnClickListener { action() } },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })
    }
    private fun input(hint: String, value: String = ""): EditText {
        val e = EditText(this).apply {
            this.hint = hint; setText(value); setSingleLine(true)
            setTextColor(0xFFFFFFFF.toInt()); setHintTextColor(0xFFADB6C0.toInt())
            setPadding(dp(10), dp(8), dp(10), dp(8)); setBackgroundColor(0xFF27313B.toInt())
        }
        root.addView(e); return e
    }

    private fun showPrivacyNotice() {
        setup("⚠️ গুরুত্বপূর্ণ গোপনীয়তা সতর্কতা")
        note("এটি একটি Gallery Backup অ্যাপ। গ্যালারির ছবি ও ভিডিওর অনুমতি দিলে এবং Telegram ব্যাকআপ চালু করলে, আপনার মিডিয়া আপনার সেট করা Telegram Bot-এর নির্ধারিত চ্যাট/চ্যানেলে পাঠানো হতে পারে।")
        note("🔴 অ্যাপটির মালিক, Bot Token বা ব্যাকআপের গন্তব্যকে বিশ্বাস না করলে অনুমতি দেবেন না।")
        note("• ব্যক্তিগত ছবি ও ভিডিও Telegram-এ আপলোড হতে পারে।\n• অন্য কারও ফোনে তাঁর স্পষ্ট সম্মতি ছাড়া ব্যবহার করবেন না।\n• অটো ব্যাকআপ ডিফল্টভাবে বন্ধ।\n• Settings থেকে যেকোনো সময় অটো ব্যাকআপ বন্ধ করা যাবে।")
        note("ব্যাকআপ চালু করার আগে Telegram Channel ID / Chat ID যাচাই করুন।")
        button("❌ বাতিল করুন") {
            getSharedPreferences("consent", MODE_PRIVATE).edit().putBoolean("notice_seen", false).apply()
            Toast.makeText(this, "আপনি সম্মতি দেননি; গ্যালারি অনুমতি চাওয়া হবে না", Toast.LENGTH_LONG).show()
            finish()
        }
        button("✅ বুঝেছি, এগিয়ে যান") {
            getSharedPreferences("consent", MODE_PRIVATE).edit().putBoolean("notice_seen", true).apply()
            showHome()
            requestPermissionsIfNeeded()
        }
    }

    private fun showHome() {
        setup("OneApp • YouTube + Backup")
        note("এক অ্যাপে YouTube, সীমিত বিজ্ঞাপন/ট্র্যাকার ব্লক এবং Telegram Gallery Backup।")
        button("▶ YouTube খুলুন") { openWeb(AppConfig.load(this).youtubeUrl) }
        button("🌐 নিজের URL খুলুন") { showUrlEntry() }
        button("☁ এখনই ব্যাকআপ করুন") { manualBackup() }
        button("⚙ সেটিংস / XX.json") { showSettings() }
        button("🔒 গোপনীয়তা সতর্কতা") { showPrivacyNotice() }
        val p = getSharedPreferences("backup_state", MODE_PRIVATE)
        val count = p.getStringSet("sent_media_ids", emptySet())?.size ?: 0
        note("ব্যাকআপ হিসেবে চিহ্নিত মিডিয়া: $count")
        val last = p.getLong("last_run", 0)
        note("শেষ ব্যাকআপ চেষ্টা: " + if (last == 0L) "এখনও নয়" else java.text.DateFormat.getDateTimeInstance().format(java.util.Date(last)))
        note("YouTube-এর সব বিজ্ঞাপন ব্লক হবে—এমন নিশ্চয়তা নেই।")
    }

    private fun showUrlEntry() {
        setup("ওয়েবসাইট খুলুন")
        val e = input("https://example.com", AppConfig.load(this).startUrl)
        button("ওপেন") { openWeb(AppConfig.safeUrl(e.text.toString())) }
        button("YouTube") { openWeb(AppConfig.load(this).youtubeUrl) }
        button("হোম") { showHome() }
    }

    private fun openWeb(url: String) {
        setup("ওয়েব ব্রাউজার")
        button("← হোম") { showHome() }
        button("↻ রিফ্রেশ") { web?.reload() }
        val v = WebView(this); web = v
        v.settings.javaScriptEnabled = true
        v.settings.domStorageEnabled = true
        v.settings.mediaPlaybackRequiresUserGesture = true
        v.webChromeClient = WebChromeClient()
        v.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                return request.url.scheme !in listOf("https", "http")
            }
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val c = AppConfig.load(this@MainActivity)
                return if (c.adblockEnabled && AdBlocker.shouldBlock(request.url.toString())) AdBlocker.response()
                else super.shouldInterceptRequest(view, request)
            }
        }
        root.addView(v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(560)))
        v.loadUrl(AppConfig.safeUrl(url))
    }

    private fun showSettings() {
        setup("সেটিংস")
        val c = AppConfig.load(this)
        note("Telegram Bot Token")
        val token = input("Bot Token", c.botToken)
        note("Telegram Channel ID / Chat ID")
        val chat = input("-1001234567890", c.channelId)
        note("YouTube URL")
        val youtube = input("https://m.youtube.com/", c.youtubeUrl)
        note("ডিফল্ট URL")
        val start = input("https://example.com/", c.startUrl)
        note("ঐচ্ছিক ad-block filter URL")
        val filter = input("https://example.com/filters.txt", c.adblockFilterUrl)
        val ad = CheckBox(this).apply { text = "অ্যাড/ট্র্যাকার ব্লক চালু"; setTextColor(-1); isChecked = c.adblockEnabled; root.addView(this) }
        val auto = CheckBox(this).apply { text = "অটো ব্যাকআপ চালু (নেটওয়ার্কে)"; setTextColor(-1); isChecked = c.autoBackup; root.addView(this) }
        button("সেটিংস সেভ করুন") {
            val new = AppConfig(token.text.toString().trim(), chat.text.toString().trim(),
                AppConfig.safeUrl(youtube.text.toString()), AppConfig.safeUrl(start.text.toString()),
                AppConfig.safeUrlOrBlank(filter.text.toString()), ad.isChecked, auto.isChecked)
            AppConfig.save(this, new); AdBlocker.refresh(new.adBlockFilterUrl)
            if (new.autoBackup && hasMediaPermissions()) scheduleBackup()
            else WorkManager.getInstance(this).cancelUniqueWork(periodicName)
            Toast.makeText(this, "সেটিংস সেভ হয়েছে", Toast.LENGTH_SHORT).show(); showHome()
        }
        button("MT Manager-এ সম্পাদিত XX.json ইমপোর্ট") {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"
            }, importRequest)
        }
        button("XX.json এক্সপোর্ট") {
            exportJson = c.toJson().toString(2)
            startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"; putExtra(Intent.EXTRA_TITLE, "XX.json")
            }, exportRequest)
        }
        button("হোম") { showHome() }
        note("Bot Token এই অ্যাপ/JSON-এ থাকলে বের করা সম্ভব। নিজের bot ব্যবহার করুন।")
    }

    private fun manualBackup() {
        if (!hasMediaPermissions()) {
            requestPermissionsIfNeeded()
            Toast.makeText(this, "অনুমতি দিন; তারপর আবার ব্যাকআপ চাপুন", Toast.LENGTH_LONG).show()
            return
        }
        val req = OneTimeWorkRequestBuilder<TelegramBackupWorker>()
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build()
        WorkManager.getInstance(this).enqueue(req)
        Toast.makeText(this, "ব্যাকআপ কিউতে যোগ হয়েছে", Toast.LENGTH_LONG).show()
    }
    private fun scheduleBackup() {
        if (!hasMediaPermissions()) return
        val req = PeriodicWorkRequestBuilder<TelegramBackupWorker>(15, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(periodicName, ExistingPeriodicWorkPolicy.UPDATE, req)
    }
    private fun hasMediaPermissions(): Boolean {
        val p = if (Build.VERSION.SDK_INT >= 33)
            arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
        else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        return p.all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }
    }
    private fun requestPermissionsIfNeeded() {
        if (hasMediaPermissions()) return
        val p = if (Build.VERSION.SDK_INT >= 33)
            arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
        else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        ActivityCompat.requestPermissions(this, p, permissionRequest)
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == permissionRequest && grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
            if (AppConfig.load(this).autoBackup) scheduleBackup()
            Toast.makeText(this, "গ্যালারি অনুমতি দেওয়া হয়েছে", Toast.LENGTH_SHORT).show()
        }
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        val uri: Uri = data.data!!
        try {
            when (requestCode) {
                importRequest -> contentResolver.openInputStream(uri)?.bufferedReader()?.use {
                    val c = AppConfig.parse(it.readText()); AppConfig.save(this, c); AdBlocker.refresh(c.adBlockFilterUrl)
                    if (c.autoBackup && hasMediaPermissions()) scheduleBackup()
                    else WorkManager.getInstance(this).cancelUniqueWork(periodicName)
                    Toast.makeText(this, "XX.json ইমপোর্ট হয়েছে", Toast.LENGTH_LONG).show(); showHome()
                }
                exportRequest -> contentResolver.openOutputStream(uri)?.bufferedWriter()?.use {
                    it.write(exportJson); Toast.makeText(this, "XX.json সেভ হয়েছে", Toast.LENGTH_SHORT).show()
                }
            }
        } catch (e: Exception) {
            Toast.makeText(this, "ফাইল প্রসেস করা যায়নি: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
    override fun onBackPressed() {
        if (web?.canGoBack() == true) web?.goBack() else showHome()
    }
}
