package com.example.oneapp

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.DataOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

class TelegramBackupWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val c = AppConfig.load(applicationContext)
        if (c.botToken.isBlank() || c.channelId.isBlank() ||
            c.botToken.contains("PASTE_YOUR") || c.channelId.contains("PASTE_YOUR")) return@withContext Result.failure()

        val prefs = applicationContext.getSharedPreferences("backup_state", Context.MODE_PRIVATE)
        val sent = prefs.getStringSet("sent_media_ids", emptySet())?.toMutableSet() ?: mutableSetOf()
        var success = 0
        var failure = 0
        val uri = MediaStore.Files.getContentUri("external")
        val projection = arrayOf(MediaStore.Files.FileColumns._ID, MediaStore.Files.FileColumns.MIME_TYPE,
            MediaStore.Files.FileColumns.DISPLAY_NAME, MediaStore.Files.FileColumns.SIZE)
        val selection = "(${MediaStore.Files.FileColumns.MEDIA_TYPE}=? OR ${MediaStore.Files.FileColumns.MEDIA_TYPE}=?)"
        val args = arrayOf(MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE.toString(),
            MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO.toString())
        applicationContext.contentResolver.query(uri, projection, selection, args,
            "${MediaStore.Files.FileColumns.DATE_ADDED} ASC")?.use { cur ->
            val idCol = cur.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID)
            val mimeCol = cur.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MIME_TYPE)
            val nameCol = cur.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DISPLAY_NAME)
            val sizeCol = cur.getColumnIndexOrThrow(MediaStore.Files.FileColumns.SIZE)
            var processed = 0
            while (cur.moveToNext() && processed < 5 && !isStopped) {
                val id = cur.getLong(idCol)
                if (id.toString() in sent) continue
                if (cur.getLong(sizeCol) > 49L * 1024L * 1024L) continue
                val itemUri = ContentUris.withAppendedId(uri, id)
                val ok = upload(itemUri, cur.getString(mimeCol) ?: "application/octet-stream",
                    cur.getString(nameCol) ?: "media_$id", c.botToken, c.channelId)
                if (ok) { sent.add(id.toString()); success++ } else failure++
                processed++
            }
        }
        prefs.edit().putStringSet("sent_media_ids", sent)
            .putLong("last_run", System.currentTimeMillis())
            .putInt("last_success_count", success).putInt("last_failure_count", failure).apply()
        if (failure > 0 && success == 0) Result.retry() else Result.success()
    }

    private fun upload(uri: Uri, mime: String, name: String, token: String, chatId: String): Boolean {
        val boundary = "----OneApp${UUID.randomUUID()}"
        var conn: HttpURLConnection? = null
        return try {
            conn = (URL("https://api.telegram.org/bot$token/sendDocument").openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"; doOutput = true
                connectTimeout = 20000; readTimeout = 30000
                setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            }
            DataOutputStream(conn.outputStream).use { out ->
                fun field(k: String, v: String) {
                    out.writeBytes("--$boundary\r\nContent-Disposition: form-data; name=\"$k\"\r\n\r\n")
                    out.write(v.toByteArray(Charsets.UTF_8)); out.writeBytes("\r\n")
                }
                field("chat_id", chatId)
                out.writeBytes("--$boundary\r\nContent-Disposition: form-data; name=\"document\"; filename=\"${name.replace("\"", "_")}\"\r\n")
                out.writeBytes("Content-Type: $mime\r\n\r\n")
                applicationContext.contentResolver.openInputStream(uri)?.use { input ->
                    val b = ByteArray(64 * 1024)
                    while (true) { val n = input.read(b); if (n <= 0) break; out.write(b, 0, n) }
                } ?: return false
                out.writeBytes("\r\n--$boundary--\r\n")
            }
            conn.responseCode in 200..299 && conn.inputStream.bufferedReader().use { it.readText() }.contains("\"ok\":true")
        } catch (_: Exception) { false } finally { conn?.disconnect() }
    }
}
