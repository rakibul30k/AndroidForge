package com.example.oneapp

import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream
import java.net.URL
import java.util.Locale

object AdBlocker {
    private val hosts = setOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "adservice.google.com", "adnxs.com", "taboola.com", "outbrain.com",
        "popads.net", "popcash.net", "exoclick.com", "trafficjunky.net",
        "adform.net", "adsystem.com"
    )
    @Volatile private var extraHosts: Set<String> = emptySet()

    fun shouldBlock(url: String): Boolean {
        val host = try { URL(url).host.lowercase(Locale.US) } catch (_: Exception) { return false }
        return (hosts + extraHosts).any { host == it || host.endsWith(".$it") }
    }
    fun refresh(url: String) {
        if (url.isBlank()) return
        Thread {
            try {
                val connection = URL(url).openConnection().apply {
                    connectTimeout = 8000
                    readTimeout = 8000
                }
                val parsed = connection.getInputStream().bufferedReader().useLines { lines ->
                    lines.map { it.trim() }
                        .filter { it.isNotBlank() && !it.startsWith("#") }
                        .mapNotNull { line ->
                            val h = line.substringAfter("||", line).substringBefore("^")
                                .substringBefore("/").trim().lowercase(Locale.US)
                            h.takeIf { it.contains('.') && !it.contains(' ') && !it.startsWith("!") }
                        }.toSet()
                }
                extraHosts = parsed
            } catch (_: Exception) {}
        }.start()
    }
    fun response() = WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
}
