RIYAN HOME INTERCOM — A to Z source project

Firebase configuration supplied for project fast-pay-5efbb is embedded in FirebaseConfig.java.

Two phones: install the same APK. Enter the same Room Code. One selects Listener, the other Talker.
The Talker microphone is sent by WebRTC; Listener plays the remote WebRTC audio through the phone speaker.
A visible foreground service keeps the intercom service running after the activity closes.

IMPORTANT: Firebase Realtime Database rules must allow the homeIntercomV2/rooms path for testing. The rules previously supplied were public and are NOT safe for production.

This project is source code. It has not been compiled in an Android build runner in this chat environment; do not treat it as APK-build verified.
