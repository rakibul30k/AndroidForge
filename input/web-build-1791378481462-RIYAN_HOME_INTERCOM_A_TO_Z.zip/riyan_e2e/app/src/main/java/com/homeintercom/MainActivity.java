package com.homeintercom;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.*;
import android.view.ViewGroup;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends Activity {
    private static final int MIC=10, NOTIF=11;
    private EditText room;
    private RadioButton listener, talker;
    @Override public void onCreate(Bundle b){ super.onCreate(b); FirebaseConfig.init(this); buildUi(); }
    private void buildUi(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(36,48,36,36);
        TextView title=new TextView(this); title.setText("RIYAN HOME INTERCOM"); title.setTextSize(25); root.addView(title);
        TextView info=new TextView(this); info.setText("একই Room Code দুই ফোনে দিন"); info.setPadding(0,18,0,12); root.addView(info);
        room=new EditText(this); room.setHint("Room Code"); room.setSingleLine(); root.addView(room,new LinearLayout.LayoutParams(-1,-2));
        RadioGroup g=new RadioGroup(this); listener=new RadioButton(this); listener.setText("শুনবে (Listener)"); listener.setChecked(true); talker=new RadioButton(this); talker.setText("কথা বলবে (Talker)"); g.addView(listener); g.addView(talker); root.addView(g);
        Button start=new Button(this); start.setText("ইন্টারকম চালু করুন"); root.addView(start);
        Button stop=new Button(this); stop.setText("বন্ধ করুন"); root.addView(stop);
        TextView status=new TextView(this); status.setText("Listener মোডে একবার চালু করলে foreground service চলবে।"); status.setPadding(0,20,0,0); root.addView(status);
        setContentView(root);
        start.setOnClickListener(v->{ String r=room.getText().toString().trim(); if(r.length()<3){room.setError("কমপক্ষে ৩ অক্ষর");return;} ensurePermissions(r); });
        stop.setOnClickListener(v->stopService(new Intent(this,IntercomService.class)));
    }
    private void ensurePermissions(String r){
        if(talker.isChecked() && ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){ ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.RECORD_AUDIO},MIC); return; }
        if(Build.VERSION.SDK_INT>=33 && ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){ ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.POST_NOTIFICATIONS},NOTIF); }
        start(r);
    }
    private void start(String r){ Intent i=new Intent(this,IntercomService.class).putExtra("room",r).putExtra("talk",talker.isChecked()); ContextCompat.startForegroundService(this,i); }
    @Override public void onRequestPermissionsResult(int q,String[] p,int[] g){super.onRequestPermissionsResult(q,p,g); if((q==MIC||q==NOTIF)&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED){String r=room.getText().toString().trim(); if(r.length()>=3) start(r);}}
}
