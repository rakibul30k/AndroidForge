package com.homeintercom;

import android.content.Context;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;

public final class FirebaseConfig {
    private FirebaseConfig() {}
    public static void init(Context context) {
        if (!FirebaseApp.getApps(context).isEmpty()) return;
        FirebaseOptions options = new FirebaseOptions.Builder()
            .setApiKey("AIzaSyCuSWA2-HGDRlisg0ng-IzkVyD4ooZASSI")
            .setApplicationId("1:432258030935:android:b81a7098967a876a603212")
            .setProjectId("fast-pay-5efbb")
            .setDatabaseUrl("https://fast-pay-5efbb-default-rtdb.firebaseio.com")
            .build();
        FirebaseApp.initializeApp(context, options);
    }
}
